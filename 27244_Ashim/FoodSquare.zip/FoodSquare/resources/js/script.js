$(document).ready(function() {

    (function($){
        //cache nav
        var nav = $("#topNav");
                
        //add indicators and hovers to submenu parents
        nav.find("li").each(function() {
            if ($(this).find("ul").length > 0) {
                
                /*$("<span>").text(" ").appendTo($(this).children(":first"));*/

                //show subnav on hover
                $(this).mouseenter(function() {
                    $(this).find("ul").stop(true, true).slideDown();
                });
                        
                //hide submenus on exit
                $(this).mouseleave(function() {
                    $(this).find("ul").stop(true, true).slideUp();
                });
            }
            });
        })(jQuery);

/* Mobile navigation */
    $('.js--nav-icon').click(function() {
        var nav = $('.js--mob-nav');
        var icon = $('.js--nav-icon i');
        
        nav.slideToggle(200);
        
        if (icon.hasClass('ion-navicon-round')) {
            icon.addClass('ion-close-round');
            icon.removeClass('ion-navicon-round');

        } else {
            icon.addClass('ion-navicon-round');
            icon.removeClass('ion-close-round');
        }        
    });
});