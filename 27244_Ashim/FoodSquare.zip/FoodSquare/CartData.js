{
  "currency": "₹",
  "categories": [
    {
      "id":"cat001",
      "category_name": "Main Menu",
      "products": [
        {
          "id": "prod-001",
          "image": "resources/img/maincourse/palak_paneer_box.jpg",
          "name": "Palak Paneer Box",
          "price": "218",
          "quantity": "0"
        },
        {
          "id": "prod-002",
          "image": "resources/img/maincourse/Amritsari_Chole.jpg",
          "name": "Amritsari Choley Box",
          "price": "80",
          "quantity": "0"
        },
        {
          "id": "prod-003",
          "image": "resources/img/maincourse/kebab_peshawari_box.jpg",
          "name": "Kebab Peshawari Box",
          "price": "178",
          "quantity": "0"
        },
        {
          "id": "prod-004",
          "image": "resources/img/maincourse/Chicken_Masala_meal.jpg",
          "name": "Chicken Masala Meal",
          "price": "200",
          "quantity": "0"
        },
        {
          "id": "prod-005",
          "image": "resources/img/maincourse/roast_cheicken_curry_box.jpg",
          "name": "Roast Chicken Curry Box",
          "price": "208",
          "quantity": "0"
        },
        {
          "id": "prod-006",
          "image": "resources/img/maincourse/Dal_makhni.jpg",
          "name": "Dal Makhni",
          "price": "180",
          "quantity": "0"
        },
        {
          "id": "prod-007",
          "image": "resources/img/maincourse/grilled_tikki_box.jpg",
          "name": "Grilled Tikki Box",
          "price": "188",
          "quantity": "0"
        }
      ]
    },
    {
      "id":"cat002",
      "category_name": "Snacks",
      "products": [
        {
          "id": "prod-008",
          "image": "resources/img/snacks/Grilled-Patty-Sandwich.jpg",
          "name": "Grilled Patty Sandwich",
          "price": "98",
          "quantity": "0"
        },
        {
          "id": "prod-009",
          "image": "resources/img/snacks/Fiery-Paneer-Sandwich.jpg",
          "name": "Fiery Paneer Sandwich",
          "price": "158",
          "quantity": "0"
        },
        {
          "id": "prod-010",
          "image": "resources/img/snacks/Superfit-Paneer-Salad.jpg",
          "name": "Superfit Paneer Salad",
          "price": "218",
          "quantity": "0"
        },
        {
          "id": "prod-011",
          "image": "resources/img/snacks/Veggie-Delight-Sandwich.jpg",
          "name": "Veggie Delight Sandwich",
          "price": "138",
          "quantity": "0"
        }
      ]
    },
    {
      "id":"cat003",
      "category_name": "Desserts and Beverages",
      "products": [
        {
          "id": "prod-012",
          "image": "resources/img/desserts_beverages/Choco-Lava-Cake.jpg",
          "name": "Choco Lava Cake",
          "price": "78",
          "quantity": "0"
        },
        {
          "id": "prod-013",
          "image": "resources/img/desserts_beverages/Desserts-Pack-of-4.jpg",
          "name": "Desserts Pack-of-4",
          "price": "198",
          "quantity": "0"
        },
        {
          "id": "prod-014",
          "image": "resources/img/desserts_beverages/Ice_tea.jpg",
          "name": "Ice Tea",
          "price": "80",
          "quantity": "0"
        },
        {
          "id": "prod-015",
          "image": "resources/img/desserts_beverages/Lemonade.jpg",
          "name": "Lemonade",
          "price": "80",
          "quantity": "0"
        }
      ]
    }
  ]
}