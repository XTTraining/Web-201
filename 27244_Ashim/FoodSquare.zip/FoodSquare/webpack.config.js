/*const path = require("path");
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
    entry: ".src/index.js",
    output: {
        filename: "bundle.js",
        path: path.join(__dirname, "dist"),
        publicPath: "/dist"
    },
    devServer: {
        contentBase: './dist'
    }
}



const config = {
                    plugins: [
                        new CopyWebpackPlugin([
                            { from: 'resources/*', to: 'dist/resources/' },
                            { from: 'vendors/*', to: 'dist/vendors/' },
                            { from: 'CartData.js', to: 'dist/CartData.js' },
                            { from: 'index.html', to: 'dist/index.html' }
                        ], 
                            { copyUnmodified: true }
                        )
                    ]
}*/

var path = require("path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const CopyWebpackPlugin = require('copy-webpack-plugin');
const webpack = require('webpack');

module.exports = {
  entry: "./src/index.js",
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "bundle.js",
    publicPath: "/dist"
  },
  devServer: {
    contentBase: './dist'
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: "min.css",
    }),
    new CopyWebpackPlugin([{
        from: 'index.html',
        to: 'dist//index.html'
      },
      {
        from: './resources/*',
        to: 'dist/resources/'
      },
      {
        from: './vendors/*',
        to: 'dist/vendors/'
      },
      {
        from: 'CartData.js',
        to: 'dist/CartData.js'
      }

    ]),
    new webpack.LoaderOptionsPlugin({
      debug: true
    }),


  ],
  module: {
    rules: [{
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ["es2015"]
          }
        }
      },
      {
        test: /\.scss$/,
        use: [{
            loader: "style-loader" // creates style nodes from JS strings
          },
          {

            loader: "css-loader" // translates CSS into CommonJS
          },
          {

            loader: "sass-loader" // compiles Sass to CSS
          }
        ]
      }
    ]
  },
  node: {
    fs: 'empty',
    // tls: 'empty'
  }
};