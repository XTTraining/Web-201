+Taste Onway

+The application has been built using HTML5, SASS, ES6, npm

+Loads a reponsive application with food categories, filters base on food type and categories, search foods

+Once restored run npm install and npm run start.

+List and display selected food in the cart with the payment details