module.exports = function(object) {
    object = object.toString();

    if(object.indexOf('1') > -1)
    {
        return 'green';
    }
    else {
        return 'red';
    }
};