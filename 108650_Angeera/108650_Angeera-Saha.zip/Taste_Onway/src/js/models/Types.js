import Fetch from './Fetch';

export default class Types {
    constructor() {
        this.categories = [];
    }
    async getTypes() {
        const data = this.fetchData();
        let res = data.result;
        this.types = res.types;
    }

    fetchData() {
        const data = new Fetch();
        data.readStorage();
        return data;
    }
 }