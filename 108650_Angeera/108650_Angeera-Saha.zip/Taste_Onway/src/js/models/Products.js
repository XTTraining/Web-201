import Fetch from './Fetch';

export default class Products {
    constructor() {
        this.products = [];
    }
    async getProducts() {
        const data = this.fetchData();
        let res = data.result;
        this.products = res.products;
    }
    getProductById(id) {
        this.getProducts();
        let product = [];
        this.products.forEach(cur => {
            if (cur.prod_id == id)
            {
                product.push({
                    prod_id: cur.prod_id,
                    prod_name: cur.prod_name,
                    type_id: cur.type_id,
                    cat_id: cur.cat_id,
                    prod_img: cur.prod_img,
                    prod_img_alt: cur.prod_img_alt,
                    prod_desc: cur.prod_desc,
                    prod_price:cur.prod_price,
                    count: cur.count,
                });
            }
        });
        return product;
    }

    fetchData() {
        const data = new Fetch();
        data.readStorage();
        return data;
    }
 }