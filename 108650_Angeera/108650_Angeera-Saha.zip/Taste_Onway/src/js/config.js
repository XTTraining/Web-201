const config = {
    apiKey: "AIzaSyAKiIqYIqRZhRpygPESdtrukhwOrRudKvY",
    authDomain: "taste-onway.firebaseapp.com",
    databaseURL: "https://taste-onway.firebaseio.com",
    projectId: "taste-onway",
    storageBucket: "",
    messagingSenderId: "526881823817"
  };

  export {config};