export const elements = {
    ProductResList: document.querySelector('.features'),
    FilterList: document.querySelector('.filter-cart-nav__menu-filter__body'),
    FilterButton: document.querySelector('.filter-cart-nav__menu-filter'),
    CategoryList: document.querySelector('.foodcategory'),
    TypeList: document.querySelector('.foodtype'),
    searchInput: document.querySelector('.search__input'),
    Order: document.querySelector('.order'),
    OrderPage: document.querySelector('.order-list'),
    HomePage: document.querySelector('.home'),
    PaymentSection: document.querySelector('.order-section'),
    CartBtn: document.querySelector('.feature-cart-btn'),
    AddtoCartBtn:document.querySelector('.feature__btn'),
    CartInputBtn:document.querySelector('.feature__input__group--button'),
    CartInputField:document.querySelector('.feature__input__group--field')
    
};