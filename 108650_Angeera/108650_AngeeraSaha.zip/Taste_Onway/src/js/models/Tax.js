import Fetch from './Fetch';

export default class Tax {
    constructor() {
        this.tax = [];
    }
    async getTax() {
        const data = this.fetchData();
        let res = data.result;
        this.tax = res.tax;
    }

    fetchData() {
        const data = new Fetch();
        data.readStorage();
        return data;
    }

    getTotalOrderPrice(products) {
        let totalOrderPrice = 0;
        products.forEach(prod =>{
            totalOrderPrice = totalOrderPrice +  prod.totalPrice;
       });
       return totalOrderPrice;
    }

    getCategoryBasedDetails(products) {
        let totalBevPrice = 0;
        let totalBevCount = 0;
        let totalOtherPrice = 0;
        let totalOtherCount = 0;
        let taxSeperatedProduct = [];
        
        this.tax.forEach(tx =>{
            products.forEach(prod =>{
                if(prod.cat_id == tx.cat_id && tx.tax_percent == 12)
                {
                    totalBevPrice = totalBevPrice + (prod.prod_price * prod.count);
                    totalBevCount = totalBevCount + prod.count;
                }else {
                    if(prod.cat_id == tx.cat_id && tx.tax_percent != 12){
                        totalOtherPrice = totalOtherPrice + (prod.prod_price * prod.count);
                        totalOtherCount = totalOtherCount + prod.count;
                    }
                }
           });
        });
        taxSeperatedProduct.push({
            totalBevPrice: totalBevPrice,
            totalBevCount: totalBevCount,
            totalOtherPrice: totalOtherPrice,
            totalOtherCount: totalOtherCount
        });
        return(taxSeperatedProduct);
    }

    getPaymentDetai(products) {
        let paymentDetail = [];
        let totalOrderPrice = this.getTotalOrderPrice(products);
        let taxSeperatedProduct = this.getCategoryBasedDetails(products);
        let gstbevProduct = (taxSeperatedProduct[0].totalBevPrice * 12/100) + taxSeperatedProduct[0].totalBevPrice;
        let gstotherProduct = (taxSeperatedProduct[0].totalOtherPrice * 5/100) + taxSeperatedProduct[0].totalOtherPrice;
        let deliveryCharge = 33.00;
        let netTotal = totalOrderPrice + gstbevProduct + gstotherProduct + deliveryCharge;
        
        paymentDetail.push({
            totalOrderPrice: totalOrderPrice.toFixed(2),
            totalBevCount: taxSeperatedProduct[0].totalBevCount,
            totalOtherCount: taxSeperatedProduct[0].totalOtherCount,
            gstbevProduct: gstbevProduct.toFixed(2),
            gstotherProduct: gstotherProduct.toFixed(2),
            deliveryCharge: deliveryCharge.toFixed(2),
            netTotal: netTotal.toFixed(2)
        });
        return paymentDetail;
    }
 }