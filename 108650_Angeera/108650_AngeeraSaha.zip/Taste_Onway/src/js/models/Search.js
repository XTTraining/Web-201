import Fetch from './Fetch';

export default class Search {
    constructor() {
    
    }
    // async getProducts() {
    //     try {
    //         const data = this.fetchData();
    //         let res = data.result;
    //         this.products = res.products;
    //     } catch (error) {
    //         alert(error);
    //     }
    // }
    // fetchData() {
    //     const data = new Fetch();
    //     data.readStorage();
    //     return data;
    // }
    getSearchResult(query, products)
    {
        if (query.includes(" ")) {
            query = query.split(" ");
        }
        let resultProduct = [];
        if (query.length > 0) {
            if (Array.isArray(query)) {
                query.forEach(el => {
                    products.forEach(e => {
                        if (e.prod_name.toLowerCase().includes(el.toLowerCase()) || e.prod_desc.toLowerCase().includes(el.toLowerCase())) {
                            {
                                var index = resultProduct.findIndex(x => x.prod_id == e.prod_id)
                                if (index == -1) {
                                    resultProduct.push({
                                        prod_id: e.prod_id,
                                        prod_name: e.prod_name,
                                        type_id: e.type_id,
                                        cat_id: e.cat_id,
                                        prod_img: e.prod_img,
                                        prod_img_alt: e.prod_img_alt,
                                        prod_desc: e.prod_desc,
                                        prod_price: e.prod_price,
                                        count: e.count
                                    });
                                }
                            }
                        }
                    });
                });
            }
            else {
                products.forEach(e => {
                    if (e.prod_name.toLowerCase().includes(query.toLowerCase()) || e.prod_desc.toLowerCase().includes(query.toLowerCase())) {
                        resultProduct.push({
                            prod_id: e.prod_id,
                            prod_name: e.prod_name,
                            type_id: e.type_id,
                            cat_id: e.cat_id,
                            prod_img: e.prod_img,
                            prod_img_alt: e.prod_img_alt,
                            prod_desc: e.prod_desc,
                            prod_price: e.prod_price,
                            count: e.count
                        });
                    }
                });
            }
        }
        return resultProduct;
    }
}