import { elements } from './base';

const renderCategory = category => {
    let markup;
    if(category.category.toLowerCase() != 'featured'){
        markup = `<button class="accordion" id="${category.category.toLowerCase()}">${category.category}</button>`;
        elements.ProductResList.insertAdjacentHTML('beforeend', markup);
        category.products.forEach(renderProduct);
    }
    
    if(category.category.toLowerCase() == 'featured')
    {
        category.products.forEach(renderProduct);
        markup =`<h2 class="features__search-result--category" id="${category.category.toLowerCase()}">${category.category}</h2>`;
        elements.ProductResList.insertAdjacentHTML('afterbegin', markup);
    }
    
};
const renderProduct = product => {
    let markup;
    if(product.count > 0){

        markup = `<div class="feature" data-id="${product.prod_id}">
    <img src="${product.prod_img}" alt="${product.prod_img_alt}" class="feature__img">
    <h5 class="feature__name">${product.prod_name}</h5>
    <div class="feature__description">
        <p>
            ${product.prod_desc}
        </p>
        <svg class=${product.type_id ===1 ? "feature__cuisine--green" : "feature__cuisine--red"}>
            <use xlink:href="img/sprite.svg#icon-controller-record"></use>
        </svg>
    </div>
    
    <div class="feature__price">
        <p>&#x20b9; ${product.prod_price}</p>
    </div>
    <div class= "feature-cart-btn" tabindex="0" role="button">
        <button class="btn feature__btn">Add to cart</button>
        <div class="feature__input__group" style="display: flex; z-index: 1; opacity: 1;">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" aria-label="remove" data-quantity="minus" data-field="quantity">
                <div class="fa fa-minus" aria-hidden="true">-</div>
                </button>
            </div>
            <input class="feature__input__group--field" aria-label="number" type="number" disabled="disabled" name="quantity" value="${product.count}">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" aria-label="add" data-quantity="plus" data-field="quantity">
                <div class="fa fa-plus" aria-hidden="true">+</div>
                </button>
            </div>
        </div>
    </div>
    <hr>
    <div class="feature__favoutite">
        <svg class="feature__favoutite__icon">
            <use xlink:href="img/sprite.svg#icon-heart"></use>
        </svg>
        <div class="feature__favoutite__count">
            400<span>favs</span>
        </div>
    </div>
</div>`;
    }
    else {
        markup = `<div class="feature" data-id="${product.prod_id}">
    <img src="${product.prod_img}" alt="${product.prod_img_alt}" class="feature__img">
    <h5 class="feature__name">${product.prod_name}</h5>
    <div class="feature__description">
        <p>
            ${product.prod_desc}
        </p>
        <svg class=${product.type_id ===1 ? "feature__cuisine--green" : "feature__cuisine--red"}>
            <use xlink:href="img/sprite.svg#icon-controller-record"></use>
        </svg>
    </div>
    
    <div class="feature__price">
        <p>&#x20b9; ${product.prod_price}</p>
    </div>
    <div class= "feature-cart-btn" tabindex="0" role="button">
        <button class="btn feature__btn">Add to cart</button>
        <div class="feature__input__group">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" data-quantity="minus" data-field="quantity">
                <div class="fa fa-minus" aria-hidden="true">-</div>
                </button>
            </div>
            <input class="feature__input__group--field" type="number" disabled="disabled" name="quantity" value="1">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" data-quantity="plus" data-field="quantity">
                <div class="fa fa-plus" aria-hidden="true">+</div>
                </button>
            </div>
        </div>
    </div>
    <hr>
    <div class="feature__favoutite">
        <svg class="feature__favoutite__icon">
            <use xlink:href="img/sprite.svg#icon-heart"></use>
        </svg>
        <div class="feature__favoutite__count">
            400<span>favs</span>
        </div>
    </div>
</div>`;
    }
    
if(product.cat_id == 6)
{
    elements.ProductResList.insertAdjacentHTML('afterbegin', markup);
}
else if(product.cat_id != 6) {
    elements.ProductResList.insertAdjacentHTML('beforeend', markup);
}
};

export const renderResults = categories => {
    categories.forEach(renderCategory);
};

export const clearResults = () => {
    elements.ProductResList.innerHTML = '';
};

