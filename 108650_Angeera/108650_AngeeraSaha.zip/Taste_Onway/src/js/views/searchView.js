import { elements } from './base';

export const getInput = () => elements.searchInput.value;

export const clearInput = () => {
    elements.searchInput.value = '';
};

export const clearResults = () => {
    elements.ProductResList.innerHTML = '';
};

export const renderSearchHeading = searchtext => {
    searchtext = toTitleCase(searchtext);
    const markup = `<div class="features__search-result--heading">
    <h2>Search Results</h2>
    <p>Related to <span>&quot;${searchtext}&quot;</span></p>
    </div>`;
    elements.ProductResList.insertAdjacentHTML('beforeend', markup);
};

export const renderResults = categories => {
    if(categories.length > 0)
    {
        categories.forEach(renderCategory);
    }else {
        renderNoResult();
    }
    
    
};

const renderNoResult = () => {
    const markup = `<h2 class="features__search-result--not-found">No result found</h2>`;
    elements.ProductResList.insertAdjacentHTML('beforeend', markup);
}
const renderCategory = category => {
    const markup =`<h2 class="features__search-result--category" id="${category.category.toLowerCase()}">${category.category}</h2>`;
    elements.ProductResList.insertAdjacentHTML('beforeend', markup);

    category.products.forEach(renderProduct);
};

const renderProduct = product => {
    let markup;
    if(product.count > 0){

        markup = `<div class="feature" data-id="${product.prod_id}">
    <img src="${product.prod_img}" alt="${product.prod_img_alt}" class="feature__img">
    <h5 class="feature__name">${product.prod_name}</h5>
    <div class="feature__description">
        <p>
            ${product.prod_desc}
        </p>
        <svg class=${product.type_id ===1 ? "feature__cuisine--green" : "feature__cuisine--red"}>
            <use xlink:href="img/sprite.svg#icon-controller-record"></use>
        </svg>
    </div>
    
    <div class="feature__price">
        <p>&#x20b9; ${product.prod_price}</p>
    </div>
    <div class= "feature-cart-btn">
        <button class="btn feature__btn">Add to cart</button>
        <div class="feature__input__group" style="display: flex; z-index: 1; opacity: 1;">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" aria-label="remove" data-quantity="minus" data-field="quantity">
                <div class="fa fa-minus" aria-hidden="true">-</div>
                </button>
            </div>
            <input class="feature__input__group--field" aria-label="number" type="number" disabled="disabled" name="quantity" value="${product.count}">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" aria-label="add" data-quantity="plus" data-field="quantity">
                <div class="fa fa-plus" aria-hidden="true">+</div>
                </button>
            </div>
        </div>
    </div>
    <hr>
    <div class="feature__favoutite">
        <svg class="feature__favoutite__icon">
            <use xlink:href="img/sprite.svg#icon-heart"></use>
        </svg>
        <div class="feature__favoutite__count">
            400<span>favs</span>
        </div>
    </div>
</div>`;
    }
    else {
        markup = `<div class="feature" data-id="${product.prod_id}">
    <img src="${product.prod_img}" alt="${product.prod_img_alt}" class="feature__img">
    <h5 class="feature__name">${product.prod_name}</h5>
    <div class="feature__description">
        <p>
            ${product.prod_desc}
        </p>
        <svg class=${product.type_id ===1 ? "feature__cuisine--green" : "feature__cuisine--red"}>
            <use xlink:href="img/sprite.svg#icon-controller-record"></use>
        </svg>
    </div>
    
    <div class="feature__price">
        <p>&#x20b9; ${product.prod_price}</p>
    </div>
    <div class= "feature-cart-btn">
        <button class="btn feature__btn">Add to cart</button>
        <div class="feature__input__group">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" data-quantity="minus" data-field="quantity">
                <div class="fa fa-minus" aria-hidden="true">-</div>
                </button>
            </div>
            <input class="feature__input__group--field" type="number" disabled="disabled" name="quantity" value="1">
            <div class="feature__input__group--button">
                <button type="button" class="button hollow box" data-quantity="plus" data-field="quantity">
                <div class="fa fa-plus" aria-hidden="true">+</div>
                </button>
            </div>
        </div>
    </div>
    <hr>
    <div class="feature__favoutite">
        <svg class="feature__favoutite__icon">
            <use xlink:href="img/sprite.svg#icon-heart"></use>
        </svg>
        <div class="feature__favoutite__count">
            400<span>favs</span>
        </div>
    </div>
</div>`;
    }
elements.ProductResList.insertAdjacentHTML('beforeend', markup);
};

const toTitleCase = str =>
{
    return str.replace(/\b\w/g, function (txt) { return txt.toUpperCase(); });
}
