import $ from 'jquery';

$(document).ready(function(){
    // This button will increment the value
    $('[data-quantity="plus"]').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get its current value
        var currentVal = parseInt($('input[name="quantity"]').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment
            if (currentVal >= 15) {    
                  $('input[name="quantity"]').val(15);
            } 
            else {
                $('input[name="quantity"]').val(currentVal + 1);
            }   
        } else {
            // Otherwise put a 0 there
            $('input[name="quantity"]').val(0);
        }
    });
    // This button will decrement the value till 0
    $('[data-quantity="minus"]').click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get its current value
        var currentVal = parseInt($('input[name="quantity"]').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            $('input[name="quantity"]').val(currentVal - 1);
        } else {
            // Otherwise put a 0 there
            $('input[name="quantity"]').val(0);
        }
    });
});
