import firebase from 'firebase';
import {config} from '../config';

firebase.initializeApp(config);

//Get a reference to the database service
const database = firebase.database();

export default class Fetch {
    constructor(){
        this.result = [];
    }
    async getData(){
        try {
            const ref = database.ref();
            ref.once("value", snapshot => {
            this.result = snapshot.val();
            this.persistData();
         });
         }
        catch(error) {
            alert(error.code);
        }
    }
    
    persistData() {
        localStorage.setItem('data', JSON.stringify(this.result));
    }

    readStorage() {
        const storage = JSON.parse(localStorage.getItem('data'));
        
        // Restoring likes from the localStorage
        if (storage) this.result = storage;
        return storage;
    }
}


