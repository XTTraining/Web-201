import Fetch from './Fetch';

export default class Categories {
    constructor() {
        this.categories = [];
    }
    async getCategories() {
        const data = this.fetchData();
        data.readStorage();
        let res = data.result;
        this.categories = res.categories;
    }

    fetchData() {
        const data = new Fetch();
        //data.getData();
        return data;
    }
 }