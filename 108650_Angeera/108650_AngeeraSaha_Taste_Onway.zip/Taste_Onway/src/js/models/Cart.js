
export default class Cart {
    constructor() {
        this.cartItems = [];
    }

    getCartItems() {
        this.readStorage();
        return this.cartItems;
    }
    updateItem(prod_id, count) {
        const item = { prod_id, count };
        this.cartItems.forEach(el => {
            if(el.prod_id == prod_id)
            {
                const index = this.cartItems.findIndex(el => el.prod_id == prod_id);
                this.cartItems.splice(index, 1);
            }
        });
        this.cartItems.push(item);
        
        // Perist data in localStorage
        this.persistData();
        return item;
    }

    deleteItem(id) {
        const index = this.cartItems.findIndex(el => el.prod_id == id);
        this.cartItems.splice(index, 1);

        // Perist data in localStorage
        this.persistData();
    }

    isSelected(id) {
        return this.cartItems.findIndex(el => el.id === id) !== -1;
    }

    getCountById(id){
        let count = 0;
        this.getCartItems();
        if (this.cartItems.length > 0) {
            this.cartItems.forEach(cart => {
                if(cart.prod_id == id){
                    count = cart.count;
                }
            });
        }
        return count;
    }
    getCartItemCount() {
        let sum = 0;
        if(this.cartItems.length > 0) {
            this.cartItems.forEach(el => {
                if(el.prod_id)
                {
                    sum = sum + el.count;
                }
            });
        }
        return sum;
    }
    getOrderedProduct(products) {
        this.getCartItems();
        let orderedProduct = [];
        // Check items that are added to the cart
        if (this.cartItems.length > 0) {
            this.cartItems.forEach(cart => {
                products.forEach(prod => {
                    if(cart.prod_id && cart.count > 0 && cart.prod_id == prod.prod_id) {
                        let totalPrice = (parseInt(cart.count) * parseInt(prod.prod_price));
                        orderedProduct.push({
                            prod_id: prod.prod_id,
                            prod_name: prod.prod_name,
                            type_id: prod.type_id,
                            cat_id: prod.cat_id,
                            prod_img: prod.prod_img,
                            prod_img_alt: prod.prod_img_alt,
                            prod_desc: prod.prod_desc,
                            prod_price:prod.prod_price,
                            count: cart.count,
                            totalPrice: totalPrice
                        });
                    }
                });
            });
        }
        return orderedProduct;
    }

    getProductTotalPriceById(id){
        this.getCartItems();

    }

    persistData() {
        localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
    }

    readStorage() {
        const storage = JSON.parse(localStorage.getItem('cartItems'));
        
        // Restoring likes from the localStorage
        if (storage) this.cartItems = storage;
    }
}