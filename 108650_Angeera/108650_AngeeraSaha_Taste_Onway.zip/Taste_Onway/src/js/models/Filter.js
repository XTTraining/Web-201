import Fetch from './Fetch';

export default class Filter {
    constructor() {
        this.products = [];
        this.count = 0;
        this.types = [];
        this.categories = [];
        this.filteredProducts = [];
        this.typeFilter = [];
        this.categoryFilter = [];
    }
    async getProducts() {
        const data = this.fetchData();
        let res = data.result;
        this.products = res.products;
    }

    async getTypes() {
        const data = this.fetchData();
        let res = data.result;
        this.types = res.types;
    }
    async getCategories() {
        const data = this.fetchData();
        data.readStorage();
        let res = data.result;
        this.categories = res.categories;
    }
    fetchData() {
        const data = new Fetch();
        data.readStorage();
        return data;
    }

    updateTypeFilter(typeFilter) {
        this.typeFilter = typeFilter;
    }

    updateCategoryFilter(categoryFilter) {
        this.categoryFilter = categoryFilter;
    }

    getTypeFilter() {
        return this.typeFilter;
    }

    getCategoryFilter() {
        return this.categoryFilter;
    }

    getAllItemsCount() {
        this.getProducts();
        return this.products.length;
    }

    getResultItemCount() {
        let type = this.getTypeFilter();
        let categories = this.getCategoryFilter();
        this.getProducts();
        this.getTypes();
        this.getCategories();
        
        let category = [];
        if(categories.length > 0)
        {
            this.categories.forEach(el => {
                categories.forEach(e => {
                    if (el.cat_name == e)
                    {
                        category.push({cat_id: el.cat_id, cat_name: el.cat_name});
                    }
                }); 
            });
        }

        let foodType = [];
        if(type.length > 0){
            this.types.forEach(el => {
                if (el.type_name == type)
                    {
                        foodType.push({type_id: el.type_id, type_name: el.type_name});
                    }
            });
        }
    
        let filteredProduct = [];
        if(category.length > 0) {
            category.forEach(el => {
                this.products.forEach(e => {
                    if (el.cat_id == e.cat_id)
                    {
                        filteredProduct.push({ 
                                type_id: e.type_id, 
                                cat_id: e.cat_id
                            });
                    }
                }) 
            });
        }
        else {
            this.categories.forEach(el => {
                this.products.forEach(e => {
                    if (el.cat_id == e.cat_id)
                    {
                        filteredProduct.push({ 
                                type_id: e.type_id, 
                                cat_id: e.cat_id
                            });
                    }
                }) 
            });
        } 

        let typeFilteredProduct = []; 

        if(foodType.length > 0){
            foodType.forEach(el => {
                filteredProduct.forEach(e => {
                    if (el.type_id == e.type_id)
                    {
                        typeFilteredProduct.push({ 
                            type_id: e.type_id, 
                            cat_id: e.cat_id
                        });
                    }
                }) ;
            });
        }
        else {
            typeFilteredProduct = filteredProduct;
        }
        return typeFilteredProduct.length;
    }

}