import { elements } from './base';

const renderType = type => {
    const markup = `<a class="filter-cart-nav__menu-filter__body__menu--list--item" tabindex="0" role="button">${type.type_name}</a>`;
    elements.TypeList.insertAdjacentHTML('beforeend', markup);
}

const renderCategory = category => {
    const markup = `<a class="filter-cart-nav__menu-filter__body__menu--list--item" tabindex="0" role="button">${category.cat_name}</a>`;
    elements.CategoryList.insertAdjacentHTML('beforeend', markup);
}

export const renderTypes = types => {
    types.forEach(renderType);
}

export const renderCategories = categories => {
    categories.forEach(renderCategory);
}

export const renderButton = products => {
    const markup = `<button class="filter-cart-nav__menu-filter__button">Apply (${products.length} Dishes)</button>`;
    elements.FilterButton.insertAdjacentHTML('beforeend', markup);
}
