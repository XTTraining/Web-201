
import { elements } from './base';
const name = require('../../templates/order.hbs');
const payment = require('../../templates/payment.hbs');

export const renderResults = products => {
	const items = products;
    elements.Order.innerHTML = name(items);
}

export const renderPaymentSection = paymentDetail => {
	const items = paymentDetail;
    elements.PaymentSection.innerHTML = payment(items);
}

