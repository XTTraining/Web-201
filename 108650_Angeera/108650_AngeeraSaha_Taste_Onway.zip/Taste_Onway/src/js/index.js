// Global app controller
import '../sass/main.scss';
import Fetch from './models/Fetch';
import Products from './models/Products';
import Categories from './models/Categories';
import Types from './models/Types';
import Cart from './models/Cart';

import * as productView from './views/productView';
import * as filterView from './views/filterView';
import * as searchView from './views/searchView';
import * as orderView from './views/orderView';
import Filter from './models/Filter';


import { elements } from './views/base';
import $ from 'jquery';
import Tax from './models/Tax';

import './carousel';
import Search from './models/Search';

const state = {};

state.data = new Fetch();
state.data.getData();
state.data.readStorage();


/** 
 * FILTER CONTROLLER
 */
const controlFilter = async () => {
    state.types = new Types();
    state.categories = new Categories();
    state.products = new Products();
    try {
        // 1) Get Types
        state.types.getTypes();
        // 2) Get Categories
        state.categories.getCategories();
        // 3) Get Products
        state.products.getProducts();

        //2 ) Render Types to the Filter on UI
        filterView.renderTypes(state.types.types);
        filterView.renderCategories(state.categories.categories);
        filterView.renderButton(state.products.products);
    }
    catch (err) {
        alert(`Something wrong with the types... ${err}`);
    }
}

/** 
 * FILTERLIST CONTROLLER
 */
const FilterList = () => {
    state.Products = new Products();
    state.types = new Types();
    state.categories = new Categories();

    try {
        state.Products.getProducts();
        state.types.getTypes();
        state.categories.getCategories();

        let typeFilter = state.filter.getTypeFilter();
        let categoryFilter = state.filter.getCategoryFilter();


        // Getting Category Id based on the selection
        let category = [];
        if (categoryFilter.length > 0) {
            state.categories.categories.forEach(el => {
                categoryFilter.forEach(e => {
                    if (el.cat_name == e) {
                        category.push({ cat_id: el.cat_id, cat_name: el.cat_name });
                    }
                });
            });
        }

        // Getting Type Id based on the selection
        let foodType = [];
        if (typeFilter.length > 0) {
            state.types.types.forEach(el => {
                if (el.type_name == typeFilter) {
                    foodType.push({ type_id: el.type_id, type_name: el.type_name });
                }
            });
        }

        // Check items that are added to the cart
        addOrderCountToProduct(state.Products.products);

        // Selecting the products based on categories
        let filteredProduct = [];
        if (category.length > 0) {
            category.forEach(el => {
                state.Products.products.forEach(e => {
                    if (el.cat_id == e.cat_id) {
                        filteredProduct.push({
                            prod_id: e.prod_id,
                            prod_name: e.prod_name,
                            type_id: e.type_id,
                            cat_id: e.cat_id,
                            prod_img: e.prod_img,
                            prod_img_alt: e.prod_img_alt,
                            prod_desc: e.prod_desc,
                            prod_price: e.prod_price,
                            cat_id: e.cat_id,
                            count: e.count
                        });
                    }
                })
            });
        }
        else {
            state.categories.categories.forEach(el => {
                state.Products.products.forEach(e => {
                    if (el.cat_id == e.cat_id) {
                        filteredProduct.push({
                            prod_id: e.prod_id,
                            prod_name: e.prod_name,
                            type_id: e.type_id,
                            cat_id: e.cat_id,
                            prod_img: e.prod_img,
                            prod_img_alt: e.prod_img_alt,
                            prod_desc: e.prod_desc,
                            prod_price: e.prod_price,
                            count: e.count
                        });
                    }
                })
            });
        }

        //Selecting  products based on type
        let typeFilteredProduct = [];

        if (foodType.length > 0) {
            foodType.forEach(el => {
                filteredProduct.forEach(e => {
                    if (el.type_id == e.type_id) {
                        typeFilteredProduct.push({
                            prod_id: e.prod_id,
                            prod_name: e.prod_name,
                            type_id: e.type_id,
                            cat_id: e.cat_id,
                            prod_img: e.prod_img,
                            prod_img_alt: e.prod_img_alt,
                            prod_desc: e.prod_desc,
                            prod_price: e.prod_price,
                            count: e.count
                        });
                    }
                });
            });
        }
        else {
            typeFilteredProduct = filteredProduct;
        }

        // Grouping product by selected categories
        let newProducts = {}
        typeFilteredProduct.forEach(product => {
            newProducts[product.cat_id] ? // check if that array exists or not in newProducts object
                newProducts[product.cat_id].push({
                    prod_id: product.prod_id,
                    prod_name: product.prod_name,
                    type_id: product.type_id,
                    prod_img: product.prod_img,
                    prod_img_alt: product.prod_img_alt,
                    prod_desc: product.prod_desc,
                    prod_price: product.prod_price,
                    cat_id: product.cat_id,
                    count: product.count
                })  // just push
                : (newProducts[product.cat_id] = [], newProducts[product.cat_id].push({
                    prod_id: product.prod_id,
                    prod_name: product.prod_name,
                    type_id: product.type_id,
                    prod_img: product.prod_img,
                    prod_img_alt: product.prod_img_alt,
                    prod_desc: product.prod_desc,
                    prod_price: product.prod_price,
                    cat_id: product.cat_id,
                    count: product.count
                })) // create a new array and push
        });

        //Creating a array grouping the products under each categories    
        let productArray = [];
        for (var catId in newProducts) {
            productArray.push({ cat_id: catId, products: newProducts[catId] });
        }

        let categoryProduct = [];
        if (category.length > 0) {
            category.forEach(el => {
                productArray.forEach(e => {
                    if (el.cat_id == e.cat_id) {
                        categoryProduct.push({ category: el.cat_name, products: e.products });
                    }
                })
            });
        }
        else {
            state.categories.categories.forEach(el => {
                productArray.forEach(e => {
                    if (el.cat_id == e.cat_id) {
                        categoryProduct.push({ category: el.cat_name, products: e.products });
                    }
                })
            });
        }

        // Render Products on UI
        productView.clearResults();
        productView.renderResults(categoryProduct);

    } catch (error) {
        alert(`Something wrong with the FilterList... ${error}`);
    }
}

/** 
 * PRODUCT CONTROLLER
 */

const controlProducts = async () => {

    state.products = new Products();
    try {
        // 1) Get Products
        await state.products.getProducts();

        // 3) Check items that are added to the cart
        addOrderCountToProduct(state.products.products);

        // 4) Getting product array group by category
        let categoryProduct = [];
        categoryProduct = groupProductByCategory(state.products.products);

        // 5) Render Products on UI
        productView.renderResults(categoryProduct);

    } catch (err) {
        alert(`Something wrong with the controlProducts... ${err}`);
    }
}

if(elements.HomePage){
    window.addEventListener('load', controlProducts);
    window.addEventListener('load', controlFilter);
}

/**
 * SEARCH CONTROLLER
 */

const controlSearch = () => {
    state.products = new Products();
    state.search = new Search();

    // 1) Get query from view
    const query = searchView.getInput();

    if (query) {
        try {
            state.products.getProducts();
            
            // 3) Check items that are added to the cart
            addOrderCountToProduct(state.products.products);

            let resultProduct = [];
            resultProduct = state.search.getSearchResult(query, state.products.products)

            let products = []
            products = groupProductByCategory(resultProduct);

            // Prepare UI for results
            searchView.clearInput();
            searchView.clearResults();
            searchView.renderSearchHeading(query);
            searchView.renderResults(products);

        } catch (err) {
            alert(`Something wrong with the controlSearch... ${err}`);
        }
    }
}

/**
 * ORDER CONTROLLER
 */

const orderController =  () => {
    state.products = new Products();
    state.tax = new Tax();
    state.cart = new Cart();

    try{
        state.products.getProducts();
        state.tax.getTax();
        // 3) Check items that are added to the cart
        
        let orderedProduct = [];
        //Getting products that are selected in the cart
        orderedProduct = state.cart.getOrderedProduct(state.products.products);
        
        let paymentDatail = [];
        //Getting Payment details with GST
        paymentDatail = state.tax.getPaymentDetai(orderedProduct);

        orderView.renderResults(orderedProduct);
        orderView.renderPaymentSection(paymentDatail);
        
    }catch(error){
        console.log(error);
    }
 }

 if(elements.OrderPage){
     window.addEventListener('load', orderController);
     $(document).ready(function ()  {
        $('.feature-cart-btn').children('.feature__btn').css('z-index', 0);
        $('.feature__btn').hide();
        $('.feature-cart-btn').children('.feature__input__group').css('display', 'flex');
        $('.feature-cart-btn').children('.feature__input__group').css('z-index', 1);
        $('.feature-cart-btn').children('.feature__input__group').css('opacity', '1');
    });
 }

/**
 * Common function to arrange products group by categories
*/
const groupProductByCategory = products => {
    let newProducts = {}
    products.forEach(product => {
        newProducts[product.cat_id] ? // check if that array exists or not in newProducts object
            newProducts[product.cat_id].push({
                prod_id: product.prod_id,
                prod_name: product.prod_name,
                type_id: product.type_id,
                prod_img: product.prod_img,
                prod_img_alt: product.prod_img_alt,
                prod_desc: product.prod_desc,
                prod_price: product.prod_price,
                cat_id:product.cat_id,
                count: product.count
            })  // just push
            : (newProducts[product.cat_id] = [], newProducts[product.cat_id].push({
                prod_id: product.prod_id,
                prod_name: product.prod_name,
                type_id: product.type_id,
                prod_img: product.prod_img,
                prod_img_alt: product.prod_img_alt,
                prod_desc: product.prod_desc,
                prod_price: product.prod_price,
                cat_id:product.cat_id,
                count: product.count
            })) // create a new array and push
    });

    let productArray = [];
    for (var catId in newProducts) {
        productArray.push({ cat_id: catId, products: newProducts[catId] });
    }

    state.Categories = new Categories();
    state.Categories.getCategories();


    let categoryProduct = [];
    state.Categories.categories.forEach(el => {
        productArray.forEach(e => {
            if (el.cat_id == e.cat_id) {
                categoryProduct.push({ category: el.cat_name, products: e.products });
            }
        })
    });

    return categoryProduct;
}

const addOrderCountToProduct = products => {

    state.cart = new Cart();
    // 1) Restore cart
    state.cart.readStorage();

    // 2) Check items that are added to the cart
    if (state.cart.cartItems.length > 0) {
        state.cart.cartItems.forEach(cart => {
            products.forEach(prod => {
                if (cart.prod_id == prod.prod_id) {
                    prod.count = cart.count;
                }
            });
        });
    }

    return products;
}

const searchSubmit = () => {
    $('.search').submit(function (e) {
        e.preventDefault();
        controlSearch();
        addToCart();
        plusMinusButton();
        addFilterItems();
        scrollDownMenuToSection();
    });
};

const orders = () => {
    $(document).on('click', '.orders', function(){
        orderController();
    });
}

/**
 * Add to cart button
 */
const addToCart = () => {
    
        $(document).on('click', '.feature-cart-btn', function (e) {
            if(elements.HomePage){
            e.stopPropagation();
            $(this).children('.feature__btn').css('z-index', 0);
            $(this).children('.feature__input__group').css('display', 'flex');
            $(this).children('.feature__input__group').css('z-index', 1);
            $(this).children('.feature__input__group').css('opacity', '1');
            let id = $(this).closest('.feature').attr('data-id');
            window.location.hash = id;
            //Get its current value
            var currentVal = 1;
            state.cart.updateItem(id, currentVal);
            let count = state.cart.getCartItemCount();
            if (count > 0) {
                $('.filter-cart-nav__notification').addClass('cart-notification');
                $('.filter-cart-nav__notification').html(count);
            }
        }
        });
        
};

/**
 * Display total count of the items added in the cart
 */
const displayCartCount = () => {
    state.cart = new Cart();
    state.cart.readStorage();
    let count = state.cart.getCartItemCount();
    if (count > 0) {
        $('.filter-cart-nav__notification').addClass('cart-notification');
        $('.filter-cart-nav__notification').html(count);
    }
}

/**
 * Add Delete cart button
 */
const plusMinusButton = () => {
    $('[data-quantity="plus"]').click(function (e) {
        
        e.preventDefault();
        e.stopPropagation();
        let id;
        if (!window.location.hash) {
            if(elements.HomePage){
                id = $(this).closest('.feature').attr('data-id');
                window.location.hash = id;
                
            } else if (elements.OrderPage){
                id = $(this).closest('.order__details').attr('data-id');
                window.location.hash = id;
            }
        }
        //Get item id from url
        const itemId = parseInt(window.location.hash.replace('#', ''));
        // Get its current value
        var currentVal = parseInt($(this).parent().siblings('input').val());

        if (!isNaN(currentVal)) {
            // Increment
            if (currentVal >= 15) {
                $(this).parent().siblings('input').val(15);
                alert("Contact us for bulk order...");
            }
            else {
                currentVal = currentVal + 1
                $(this).parent().siblings('input').val(currentVal);
                state.cart.updateItem(itemId, currentVal);
                if(elements.HomePage){
                    let count = state.cart.getCartItemCount();
                    if (count > 0) {
                        $('.filter-cart-nav__notification').addClass('cart-notification');
                        $('.filter-cart-nav__notification').html(count);
                    }
                }else if (elements.OrderPage){
                    state.products = new Products();
                    state.products.getProducts();
                    state.tax= new Tax();
                    state.tax.getTax();
                    let product = [];
                    let orderedProducts = [];
                    let taxDetail = [];
                    let count = state.cart.getCountById(itemId);
                    product = state.products.getProductById(itemId);
                    let totalPrice = product[0].prod_price * count;
                    $('.order__total-price').html(totalPrice);
                    orderedProducts = state.cart.getOrderedProduct(state.products.products)
                    taxDetail = state.tax.getPaymentDetai(orderedProducts);
                    
                    $('.basket-total').html(taxDetail[0].totalOrderPrice);
                    $('.beverage').children('.tax-total-block__inner--left').html("<strong>GST 12% on "+taxDetail[0].totalBevCount +" Beverage(s)/Snack(s) items</strong>");
                    $('.other').children('.tax-total-block__inner--left').html("<strong>GST 5% on "+taxDetail[0].totalOtherCount+" other items</strong>");
                    $('.beverage').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span class=\"tax-total\">"+taxDetail[0].gstbevProduct+"</span></strong>");
                    $('.other').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span class=\"tax-total\">"+taxDetail[0].gstotherProduct+"</span></strong>");
                    $('.delivery').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span>"+taxDetail[0].deliveryCharge+"</span></strong>");
                    $('.inner-net-total-block').children('.inner-net-total-block--right').html("<strong><small>&#x20b9;</small> <span class=\"net-total\">"+taxDetail[0].netTotal+"</span></strong><a class=\"btn checkout-order\" href=\"#\">Checkout</a>");
                }
            }
        } else {
            // Otherwise put a 0 there
            $(this).parent().siblings('input').val(0);
            state.cart.deleteItem(itemId);
            if(elements.HomePage){
                let count = state.cart.getCartItemCount();
                if (count > 0) {
                    $('.filter-cart-nav__notification').addClass('cart-notification');
                    $('.filter-cart-nav__notification').html(count);
                }
            } else if (elements.OrderPage){
                state.products = new Products();
                state.products.getProducts();
                state.tax= new Tax();
                state.tax.getTax();
                let product = [];
                let orderedProducts = [];
                let taxDetail = [];
                let count = state.cart.getCountById(itemId);
                product = state.products.getProductById(itemId);
                let totalPrice = product[0].prod_price * count;
                $('.order__total-price').html(totalPrice);
                orderedProducts = state.cart.getOrderedProduct(state.products.products)
                taxDetail = state.tax.getPaymentDetai(orderedProducts);
                
                $('.beverage').children('.tax-total-block__inner--left').html("<strong>GST 12% on "+taxDetail[0].totalBevCount +" Beverage(s)/Snack(s) items</strong>");
                $('.beverage').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span class=\"tax-total\">"+taxDetail[0].gstbevProduct+"</span></strong>");
                $('.other').children('.tax-total-block__inner--left').html("<strong>GST 5% on "+taxDetail[0].totalOtherCount+" other items</strong>");
                $('.other').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span class=\"tax-total\">"+taxDetail[0].gstotherProduct+"</span></strong>");
                $('.delivery').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span>"+taxDetail[0].deliveryCharge+"</span></strong>");
                $('.inner-net-total-block').children('.inner-net-total-block--right').html("<strong><small>&#x20b9;</small> <span class=\"net-total\">"+taxDetail[0].netTotal+"</span></strong><a class=\"btn checkout-order\" href=\"#\">Checkout</a>");
            }
        }
    });
    // This button will decrement the value till 0
    $('[data-quantity="minus"]').click(function (e) {
        // Stop acting like a button
        e.preventDefault();
        e.stopPropagation();
        let id;
        if (!window.location.hash) {
            if(elements.HomePage){
                id = $(this).closest('.feature').attr('data-id');
                window.location.hash = id;
                
            } else if (elements.OrderPage){
                id = $(this).closest('.order__details').attr('data-id');
                window.location.hash = id;
            }
        }
        // Get its current value
        var currentVal = parseInt($(this).parent().siblings('input').val());
        //Get item id from url
        const itemId = parseInt(window.location.hash.replace('#', ''));
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 0) {
            // Decrement one
            currentVal = currentVal - 1
            if (currentVal === 0) {
                if(elements.HomePage){
                $(this).closest('.feature__btn').css('z-index', 1);
                $(this).closest('.feature__input__group').css('display', 'none');
                $(this).closest('.feature__input__group').css('z-index', '0');
                $(this).closest('.feature__input__group').css('opacity', '0');
                state.cart.deleteItem(itemId);
                let count = state.cart.getCartItemCount();
                    if (count > 0) {
                        $('.filter-cart-nav__notification').addClass('cart-notification');
                        $('.filter-cart-nav__notification').html(count);
                    }
                } else if(elements.OrderPage){
                    state.cart.deleteItem(itemId);
                    $(".order__details").remove();
                }
            }
            else {
                $(this).parent().siblings('input').val(currentVal);
                state.cart.updateItem(itemId, currentVal);
                let count = state.cart.getCartItemCount();
                if(elements.HomePage){
                    if (count > 0) {
                        $('.filter-cart-nav__notification').addClass('cart-notification');
                        $('.filter-cart-nav__notification').html(count);
                    }
                }else if (elements.OrderPage){
                    state.products = new Products();
                    state.products.getProducts();
                    state.tax= new Tax();
                    state.tax.getTax();
                    let product = [];
                    let orderedProducts = [];
                    let taxDetail = [];
                    let count = state.cart.getCountById(itemId);
                    product = state.products.getProductById(itemId);
                    let totalPrice = product[0].prod_price * count;
                    $('.order__total-price').html(totalPrice);
                    orderedProducts = state.cart.getOrderedProduct(state.products.products)
                    taxDetail = state.tax.getPaymentDetai(orderedProducts);
                    
                    $('.basket-total').html(taxDetail[0].totalOrderPrice);
                    $('.beverage').children('.tax-total-block__inner--left').html("<strong>GST 12% on "+taxDetail[0].totalBevCount +" Beverage(s)/Snack(s) items</strong>");
                    $('.other').children('.tax-total-block__inner--left').html("<strong>GST 5% on "+taxDetail[0].totalOtherCount+" other items</strong>");
                    $('.beverage').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span class=\"tax-total\">"+taxDetail[0].gstbevProduct+"</span></strong>");
                    $('.other').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span class=\"tax-total\">"+taxDetail[0].gstotherProduct+"</span></strong>");
                    $('.delivery').children('.tax-total-block__inner--right').html("<strong><small>&#x20b9;</small> <span>"+taxDetail[0].deliveryCharge+"</span></strong>");
                    $('.inner-net-total-block').children('.inner-net-total-block--right').html("<strong><small>&#x20b9;</small> <span class=\"net-total\">"+taxDetail[0].netTotal+"</span></strong><a class=\"btn checkout-order\" href=\"#\">Checkout</a>");
                }
            }
        }
        else {
            if(elements.HomePage){
                state.cart.deleteItem(cartItemId);
                $(this).closest('.feature__btn').css('z-index', 1);
                $(this).closest('.feature__input__group').css('display', 'none');
                $(this).closest('.feature__input__group').css('z-index', '0');
                $(this).closest('.feature__input__group').css('opacity', '0');
            } else if(elements.OrderPage){
                state.cart.deleteItem(cartItemId);
                $(".order__details").remove();
            }
        }
    });
};

/** 
/* Show/Hide filter 
*/
const showFilter = () => {
    $(document).on('click', '.filter', function () {
        $(this).siblings('.filter-cart-nav__menu-filter').toggle();
    });
};

const filterSelect = () => {
    $('.filter-cart-nav__menu-filter__body__menu--list--item').click(function () {
        if ($(this).closest('.type').length != 0) {
            $(this).siblings('.filter-cart-nav__menu-filter__body__menu--list--item').removeClass('selected');
            $(this).toggleClass('selected');

        }
        else if ($(this).closest('.category').length != 0){
            $(this).toggleClass('selected');
        }
        e.stopPropagation();
        resetFilter();
        getSelectedFilters();
        addFilterItems();
    });
};

/** 
    /* Hide filter if clicked outside
    */
const hideFilteter = () => {
    $(document).click(function (event) {
        if (!($(event.target).closest('.filter').length || $(event.target).closest('.filter-cart-nav__menu-filter').length)) {
            if ($('.filter-cart-nav__menu-filter').is(":visible")) {
                $('.filter-cart-nav__menu-filter').hide();
            }
        }
        else if ($(event.target).closest('.filter').length || $(event.target).closest('.filter-cart-nav__menu-filter').length){
            filterSelect();
        }
        
    });
}
/** 
* Show the filter result
*/
const addFilterItems = () => {
    $('.filter-cart-nav__menu-filter__button').click(function () {
        FilterList();
        addToCart();
        plusMinusButton();
        scrollDownMenuToSection();
    });
};

/** 
 /* Reset filter 
 */
const resetFilter = () => {
    $(document).on('click', '.filter-cart-nav__menu-filter__header--reset-filter', function () {
        $('.filter-cart-nav__menu-filter__body__menu--list--item').removeClass('selected');
        state.filter.updateTypeFilter("");
        state.filter.updateCategoryFilter("");
        var count = state.filter.getAllItemsCount();
        var buttonText = 'Apply (' + count + ' Dishes)';
        $(this).closest('.filter-cart-nav__menu-filter__header').next().next().html(buttonText);
        $(this).closest('.filter-cart-nav__menu-filter__header').siblings('.filter-cart-nav__menu-filter__button').removeClass('disabled');
    });

};

//**
/* Get selected filters
*/
const getSelectedFilters = () => {
    $('.foodtype').click(function () {
        var text = [];
        text = $(this).children('.selected').text();
        state.filter.updateTypeFilter(text);
        var count = state.filter.getResultItemCount();
        var buttonText = 'Apply (' + count + ' Dishes)';
        $(this).closest('.filter-cart-nav__menu-filter__body').next().html(buttonText);
        $(this).closest('.filter-cart-nav__menu-filter__body').siblings('.filter-cart-nav__menu-filter__button').removeClass('disabled');
    });

    $('.foodcategory').click(function () {
        var resultArray = [];
        $(this).children('.selected').each(function () {
            resultArray.push($(this).text());
        });
        state.filter.updateCategoryFilter(resultArray);
        var count = state.filter.getResultItemCount();
        var buttonText = 'Apply (' + count + ' Dishes)';
        $(this).closest('.filter-cart-nav__menu-filter__body').next().html(buttonText);
        if (count == 0) {
            $(this).closest('.filter-cart-nav__menu-filter__body').siblings('.filter-cart-nav__menu-filter__button').addClass('disabled');
        }
        else {
            $(this).closest('.filter-cart-nav__menu-filter__body').siblings('.filter-cart-nav__menu-filter__button').removeClass('disabled');
        }
    });
};

/**
 * Menu to scroll down sections
 */

const scrollDownMenuToSection = () => {
    $("a.nav__link").click(function (event) {
        //event.preventDefault();
        $("html, body").animate({ scrollTop: $($(this).attr("href")).offset().top }, 500);
    });
}

/**
 * Hamburger Menu scrolling in and out
 */
$('.navigation__button').click(function() {
    // Calling a function in case you want to expand upon this.
    toggleNav();
  });
$('.navigation__link').click(function() {
    // Calling a function in case you want to expand upon this.
    toggleNav();
  });  

const toggleNav = () =>{
    if ($('#site-wrapper').hasClass('show-nav')) {
      // Do things on Nav Close
      $('#site-wrapper').removeClass('show-nav');
    } else {
      // Do things on Nav Open
      $('#site-wrapper').addClass('show-nav');
    }
}

/**
 * Remove hash value from url if clicked other then feature products
 */
const removeHash = () => {
    $(document).click(function (event) {
        if (!($(event.target).closest('.feature-cart-btn').length)) {
            window.location.hash='';
            history.pushState('', document.title, window.location.pathname); // nice and clean
        }
    });
};

/*
* Document Ready
*/

$(document).ready(function () {
    addToCart();
    plusMinusButton();
    showFilter();
    resetFilter();
    //filterSelect();
    getSelectedFilters();
    addFilterItems();
    hideFilteter();
    searchSubmit();
    displayCartCount();
    scrollDownMenuToSection();
    orders();
    removeHash();
});

//Restore cart on page load
window.addEventListener('load', () => {

    state.cart = new Cart();
    // Restore cart
    state.cart.readStorage();

    state.filter = new Filter();
});








