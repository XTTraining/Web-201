var appFirebase = require('../firebase/init');
var carouselModel = require('../models/carousel');

let carouselRef = appFirebase.database().ref("Carousel").orderByChild("title");
carouselRef.once('value', function(snapshot) {

    snapshot.forEach(function(childSnapShot) {
        carouselModel.push({
            "title":childSnapShot.val().title,
            "description":childSnapShot.val().description,
            "image":childSnapShot.val().image,
            "link":childSnapShot.val().link
        });
    });
    return true;
}),function(error) {
    console.log("Error: DB => Carousel");
    alert("Err: " + error);
    return false;
};

module.exports = carouselModel;


// export const getCarousels =async (domElement) => {
//     let carouselRef = appFirebase.database().ref("Carousel").orderByChild("title");
//     await carouselRef.once('value', function(snapshot) {
//         console.log("2");
//         let bulletHtml = '';
//         let carouselHtml = '';
//         let idx=1;
//         snapshot.forEach(function(childSnapShot) {
//             bulletHtml +=`<li class="carousel-bullet"></li>`;

//             carouselHtml += 
//             `
//             <li class="carousel-item">
//                 <div class="item-${idx++}">
//                     <div class="image-container">
//                         <img src="${childSnapShot.val().image}" alt="A" class="image">
//                     </div>
//                     <div class="carousel-content">
//                         <h1>${childSnapShot.val().title}</h1>
//                         <p class="description">${childSnapShot.val().description}</p>
//                         <a href="${childSnapShot.val().link}" class="btn btn-full">Show ...</a>
//                     </div>
//                 </div>
//             </li>
//             `;
//         });
//         //domElement.insertAdjacentHTML('beforeend', carouselTemplate(bulletHtml, carouselHtml));
//         domElement.innerHTML = carouselTemplate(bulletHtml, carouselHtml);
//         //alert("3");
//         return true;
//     }),function(error) {
//         console.log("Error: DB => Carousel");
//         alert("Err: " + error);
//         return false;
//     };
// };
