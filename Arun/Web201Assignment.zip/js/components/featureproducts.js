var appFirebase = require('../firebase/init');
var featureProductData = require('../models/product');

let ref = appFirebase.database().ref("FeatureProduct").orderByChild("categoryName");
ref.once('value', function(snapshot) {
    snapshot.forEach(function(childSnapShot) {
        featureProductData.push({
            "pcode":childSnapShot.val().pcode,
            "name":childSnapShot.val().name,
            "serving":childSnapShot.val().Serving,
            "imageUrl":`/img/products/${childSnapShot.val().imageUrl}`,
            "categoryId":childSnapShot.val().category,
            "categoryName":childSnapShot.val().categoryName,
            "price":childSnapShot.val().mrp,
            "type":childSnapShot.val().type,
            "types":childSnapShot.val().types
        });
    });
    return true;
}),function(error) {
    console.log("Error: DB => Product");
    return false;
};

module.exports = featureProductData;

