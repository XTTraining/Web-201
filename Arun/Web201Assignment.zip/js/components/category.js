var appFirebase = require('../firebase/init');
var categoryModel = require('../models/category');

let ref = appFirebase.database().ref("Category").orderByChild("name");
ref.once('value', function(snapshot) {

    snapshot.forEach(function(childSnapShot) {
        categoryModel.push({
            "name":childSnapShot.val().name,
            "id":childSnapShot.val().id
        });
    });
    console.log(categoryModel);
    return true;
}),function(error) {
    console.log("Error: DB => Category");
    alert("Err: " + error);
    return false;
};

module.exports = categoryModel;
