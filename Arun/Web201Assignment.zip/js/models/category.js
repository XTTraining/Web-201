module.exports = product = [];

// {
//     "id":"C01",
//     "name":"STARTES",
//     "parentID":null
// }
