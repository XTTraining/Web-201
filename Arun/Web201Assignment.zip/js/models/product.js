module.exports = product = [];

// {
//     "name": "Paneer Tikka Shaslik",
//     "Serving" : "8 pieces",
//     "category": "C01",
//     "mrp": "150.00"
//     ,"imageUrl" : "food1.jpg"
// }