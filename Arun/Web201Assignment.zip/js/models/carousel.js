module.exports = carousel = [];

//
// {
//     "title":"",
//     "description":"",
//     "link":"",
//     "image":""
// }
