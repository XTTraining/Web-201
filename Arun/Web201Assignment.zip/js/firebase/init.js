var firebase = require('firebase');

// import * as firebase from 'firebase';

let config = {
    apiKey: "AIzaSyAWWbAhVQsnsDNA_TbDa3ZOYjPF5KpMtdE",
    authDomain: "assignmentweb201.firebaseapp.com",
    databaseURL: "https://assignmentweb201.firebaseio.com",
    projectId: "assignmentweb201",
    storageBucket: "assignmentweb201.appspot.com",
    messagingSenderId: "652339367266"
};
firebase.initializeApp(config);

module.exports = firebase;
