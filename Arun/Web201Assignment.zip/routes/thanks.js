let express = require('express');
let router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  // console.log('Req Cookies: ', req.cookies);
  res.render('thanks', { title: 'Khana Khazana - Order Confirm'});
  next();
});

module.exports = router;
