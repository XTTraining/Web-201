let express = require('express');
let router = express.Router();

let carouselData = require('../js/components/carousel');
let featureProductData = require('../js/components/featureproducts');

let Model = {
  carousel: carouselData,
  featureProduct: featureProductData
};

/* GET home page. */
router.get('/', function(req, res, next) {
  let cookie = req.cookies.cookieName;
  res.cookie('feature', Model);
  if (cookie) {
  }
  // console.log('Req Cookies: ', req.cookies);
  res.render('index', { title: 'Khana Khazana', 'name' : 'full stack developer', 'Model': Model });
  next();
});

module.exports = router;
