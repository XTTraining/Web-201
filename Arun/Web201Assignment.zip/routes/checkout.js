var express = require("express");
var router = express.Router();

let featureProductData = require("../js/components/featureproducts");

let cartModel = [];

/* GET Cart page. */
router.get("/", function(req, res, next) {
  let filterCart = [];

  if (req.cookies && req.cookies.cart) {
    let cokieCart = JSON.parse(req.cookies.cart);

    cokieCart.forEach(function(cartItem, index) {
      let filterObj = featureProductData.filter(function(item) {
        return item.pcode === cartItem.pcode;
      });
      filterCart.push(filterObj[0]);
    });
  }
  console.log("filterCart: ", filterCart);
  res.render("checkout", {
    title: "Khana Khazana - Checkout",
    name: "full stack developer",
    Model: filterCart
  });

  next();
});

module.exports = router;
