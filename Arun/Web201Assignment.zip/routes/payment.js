let express = require('express');
let router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  // console.log('Req Cookies: ', req.cookies);
  res.render('payment', { title: 'Khana Khazana - Payment'});
  next();
});

module.exports = router;
