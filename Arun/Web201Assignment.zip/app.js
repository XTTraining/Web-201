const express = require('express');
const bodyparser = require('body-parser');
const path = require('path');
var cookieParser = require('cookie-parser');
// const httpError = require('http-errors');

//Router Path
var indexRouter = require('./routes/index');
var cartRouter = require('./routes/cart');
var checkoutRouter = require('./routes/checkout');
var paymentRouter = require('./routes/payment');
var thanksRouter = require('./routes/thanks');

let app = express();
let port = process.env.PORT || 3001;

//View Engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

//Middleware
const myConsoleLog = function(req, res, next) {
    console.log("myConsoleLog - Middleware has run");
    next();
};

const serverResponseTime = function(req, res, next) {
    console.log("serverResponseTime - Middleware has run");
    req.requestTime = Date.now();
    next();
};

app.use(myConsoleLog);
app.use(serverResponseTime);

app.use(cookieParser());
app.use(express.urlencoded({extended: false}));
app.use('/', express.static(path.join(__dirname, '/public')));

app.use('/', indexRouter);
app.use('/index', indexRouter);
app.use('/cart', cartRouter);
app.use('/checkout', checkoutRouter);
app.use('/payment', paymentRouter);
app.use('/thanks',thanksRouter);

// Route
// app.get("/cart" , (req, res) => {
//     res.redirect("/index.html");
//     res.send("This is first route");
// });

// app.get("/index" , (req, res) => {
//     // res.send("This is index route");
//     res.redirect("/index.html");
// });


app.get("/about" , (req, res) => {
    res.send(`This is about route, and server takes time to load response is [${req.requestTime}]`);
    console.log(`This is about route, and server takes time to load response is [${req.requestTime}]`);
});

// //catch 404
// app.use(function(req, res, nex) {
//     next(httpError(404));
// });

// //Error Handler
// app.use(function(err, req, res, next) {
//     res.locals.message = err.message;
//     res.locals.error = req.app.get('env') == 'development' ? err: {};

//     res.status(err.status || 500);
//     res.render('error');
// });

app.listen(port, () => console.log(`App is running @ ${port}`));

