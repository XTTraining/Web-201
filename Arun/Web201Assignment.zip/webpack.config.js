const path = require('path');
const htmlPlugin = require('html-webpack-plugin');
const copyPlugin = require('copy-webpack-plugin');

module.exports = {
    entry: './src/js/controllers/index.js',
    output:{
        path: path.resolve(__dirname,'public'),
        filename: 'js/bundle.js'
    },
    devServer:{
        contentBase: './public'
    },
    plugins:[
        new htmlPlugin({
            filename: 'cart.html',
            template: './src/cart.html'
        }),
        new copyPlugin([
            { from: "./src/css/style.css", to: "./css/style.css"},
            { from: "./src/img", to: "./img"}
        ])
    ]
};
