import {DOMElement, ElementClasses} from '../views/domelement';

window.cartItems = window.cartItems || [];

export const findItemInCart = (from, field, equalTo) => {
    const itemIndex = from.findIndex(function(item, itemIndex) {
        return item[field].toLowerCase() === equalTo.toLowerCase()
    });
    return from[itemIndex];
};

export const findItemCartIndex = (from, field, equalTo) => {
    const itemIndex = from.findIndex(function(item, itemIndex) {
        return item[field].toLowerCase() === equalTo.toLowerCase()
    });
    return itemIndex;
};

export const empatyCart = () => {
    window.localStorage.cartItem = "";
    window.cartItems = [];
    document.cookie = "cart=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
};

export const Updatecart = (thispcode, field, updateQty, thisPrice) => {
    if (window.cartItems && window.cartItems.length > 0) {
        let itemIndex = findItemCartIndex(window.cartItems, field, thispcode);
        if (itemIndex > -1) {
            let qty = parseInt(window.cartItems[itemIndex].qty);
            if (updateQty > 0) {
                window.cartItems[itemIndex].qty = updateQty;
            }
            else {
                window.cartItems.splice(itemIndex,1);
            }
        }
        else if (updateQty > 0) {
            window.cartItems.push({ "pcode": thispcode, "name": "", "qty": updateQty, "price": thisPrice});
        }
    }
    else if (updateQty > 0) {
        window.cartItems.push({ "pcode": thispcode, "name": "", "qty": updateQty, "price": thisPrice});
    }
    setCookie();
    window.localStorage.cartItem = JSON.stringify(window.cartItems);
}

const setCookie = () => {
     document.cookie = "cart = " + JSON.stringify(window.cartItems);
};

document.addEventListener("DOMContentLoaded", function(event) {
    DOMElement.mobilemenu.addEventListener('click', function() {
        DOMElement.sidenav.classList.add(ElementClasses.sideNavActive);
        DOMElement.bgOverlayPopup.classList.add(ElementClasses.bgOverlayPopup);
    });
    
    DOMElement.bgOverlayPopup.addEventListener('click', function() {
        DOMElement.sidenav.classList.remove(ElementClasses.sideNavActive);
        DOMElement.bgOverlayPopup.classList.remove(ElementClasses.bgOverlayPopup);
    });
});
