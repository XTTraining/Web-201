// import {getCarousels} from '../firebase/database/carousel';

let carousel = document.querySelector('.carousel');

if (carousel) {
    let container = carousel.querySelector('.carousel-container');
    let prevBtn = carousel.querySelector('.carousel-prev');
    let nextBtn = carousel.querySelector('.carousel-next');
    let pagination = carousel.querySelector('.carousel-pagination');
    let bullets = [].slice.call(carousel.querySelectorAll('.carousel-bullet'));

    let totalItems = container.querySelectorAll('.carousel-item').length;
    let percent = (100 / totalItems);
    let currentIndex = 0;

    const next = () => {
        slideTo(currentIndex + 1);
    };

    const prev = () => {
        slideTo(currentIndex - 1);
    }

    const slideTo = (index) => {
        index = index < 0 ? totalItems - 1 : index >= totalItems ? 0 : index;
        container.style.WebkitTransform = container.style.transform = 'translate(-' + (index * percent) + '%, 0)';
        bullets[currentIndex].classList.remove('active-bullet');
        bullets[index].classList.add('active-bullet');
        currentIndex = index;
    }
        
    bullets[currentIndex].classList.add('active-bullet');
    prevBtn.addEventListener('click', prev, false);
    nextBtn.addEventListener('click', next, false);
    console.log("IN 3");

    pagination.addEventListener('click', function(e) {
        var index = bullets.indexOf(e.target);
        if (index !== -1 && index !== currentIndex) {
            slideTo(index);
        }
    }, false);

}