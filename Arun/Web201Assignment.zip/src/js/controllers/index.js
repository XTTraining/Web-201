import {DOMElement, ElementClasses} from '../views/domelement';
import * as carousel from './carousel';
import {Updatecart, empatyCart} from '../common/components';
import { debug } from 'util';



document.addEventListener("DOMContentLoaded", function(event) {
    window.qtyMaxLimit = 10;

    window.cartItems = window.cartItems || [];
    if (window.cartItems.length < 1 && window.localStorage.cartItem) {
        window.cartItems = JSON.parse(window.localStorage.cartItem)

        DOMElement.cartElement.innerText = window.cartItems.length;
        DOMElement.cartMobileElement.innerText = `(${window.cartItems.length}) Cart`;

        let cartPricetotal = 0;
        window.cartItems.forEach(function(item) {

            let productElement = document.querySelector(`#${item.pcode}`);
            if (productElement) {
                let qtyElementMobile = productElement.querySelector('div.qty-m span.qty');
                
                if (qtyElementMobile) {
                    qtyElementMobile.innerText = item.qty;
                    
                    let itemPrice = qtyElementMobile.parentElement.parentElement.parentElement.querySelector('span.item-price-mobile');
                    if (itemPrice) {
                        let itemMrp = parseFloat(itemPrice.parentElement.parentElement.querySelector('span.product-price-mobile').innerText);

                        itemPrice.innerText = itemMrp * item.qty;
                        // cartPricetotal += (itemMrp * item.qty);
                    }
                }

                let qtyElement = productElement.querySelector('a.qty span.qty');
                
                if (qtyElement) {
                    qtyElement.innerText = item.qty;
                    
                    let itemPrice = qtyElement.parentElement.parentElement.parentElement.querySelector('span.item-price');
                    if (itemPrice) {
                        let itemMrp = parseFloat(itemPrice.parentElement.parentElement.querySelector('span.product-price').innerText);

                        itemPrice.innerText = itemMrp * item.qty;
                        cartPricetotal += (itemMrp * item.qty);
                    }
                }


                let updateAddToCartButton = productElement.querySelector('.action button span');
                if (updateAddToCartButton) {
                    updateAddToCartButton.innerText =  "Update Cart";
                };
            }
        });

        if (DOMElement.subtotal) {
            DOMElement.subtotal.innerText = cartPricetotal;
            DOMElement.grandSummary.innerText = cartPricetotal;
        }
    }


    /////////////////////////////////////////////////////////////////
    // Home Page => Logo => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.logo) {
        DOMElement.logo.addEventListener('click', function(elem) {
            window.location.href = "/";
        });
    }


    /////////////////////////////////////////////////////////////////
    // Cart Page => Checkout for payment => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.cartCheckoutbtn) {
        DOMElement.cartCheckoutbtn.addEventListener('click', function(elem) {
            window.location.href = "/checkout";
        });
    }


    /////////////////////////////////////////////////////////////////
    // Cart Page => Continue Shopping => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.continueShop) {
        DOMElement.continueShop.addEventListener('click', function(e) {
            window.location.href = "/index";
        });
    }

    /////////////////////////////////////////////////////////////////
    // Cart Page => Empty Cart => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.clearCart) {
        DOMElement.clearCart.addEventListener('click', function(e) {
            if (DOMElement.productsElement) {
                DOMElement.productsElement.forEach(function(elem) {
                    console.log(elem);
                    elem.remove();
                });
            }
            empatyCart();
            DOMElement.cartElement.innerText = window.cartItems.length;
            DOMElement.cartMobileElement.innerText = `(${window.cartItems.length}) Cart`;
            updateSummaryTotal();
        });
    }

    /////////////////////////////////////////////////////////////////////
    // Cart Page => Update Single Item's quantity in Cart => Click Event
    /////////////////////////////////////////////////////////////////////
    if (DOMElement.updateCartButton) {
        DOMElement.updateCartButton.forEach(function(elem) {
            elem.addEventListener("click", function() {
                let qtyElement = this.parentElement.parentElement.querySelector('a.qty span.qty');
                let qty = parseInt(qtyElement.innerText);
                if (qty > -1) {
                    let thispcode = this.parentElement.parentElement.querySelector('a.qty span.qty').getAttribute("id").replace("qty-",'');
                    let thisPrice = parseFloat(this.parentElement.parentElement.querySelector('span.product-price').innerText);

                    Updatecart(thispcode, "pcode", qty, thisPrice);

                    updateSummaryTotal();
                }
            });
        });

        DOMElement.updateMobileCartButton.forEach(function(elem) {
            elem.addEventListener("click", function() {
                let qtyElement = this.parentElement.parentElement.parentElement.querySelector('div.qty-m span.qty');
                let qty = parseInt(qtyElement.innerText);
                if (qty > -1) {
                    let thispcode = this.parentElement.parentElement.parentElement.querySelector('div.qty-m span.qty').getAttribute("id").replace("qty-",'');
                    let thisPrice = parseFloat(this.parentElement.parentElement.parentElement.querySelector('span.product-price-mobile').innerText);

                    Updatecart(thispcode, "pcode", qty, thisPrice);

                    updateSummaryTotal();
                }
            });
        });
    }

    /////////////////////////////////////////////////////////////////
    // Cart Page => Remove Single Item From Cart => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.removeCartButton) {
        DOMElement.removeCartButton.forEach(function(elem) {
            elem.addEventListener("click", function() {
                let itemRoot = this.parentElement.parentElement;

                let thispcode = this.parentElement.parentElement.querySelector('a.qty span.qty').getAttribute("id").replace("qty-",'');
                let thisPrice = parseFloat(this.parentElement.parentElement.querySelector('span.product-price').innerText);

                Updatecart(thispcode, "pcode", 0, thisPrice);

                updateSummaryTotal();

                itemRoot.remove();
                DOMElement.cartElement.innerText = window.cartItems.length;
                DOMElement.cartMobileElement.innerText = `(${window.cartItems.length}) Cart`;
            });
        });

        DOMElement.removeMobileCartButton.forEach(function(elem) {
            elem.addEventListener("click", function() {
                let itemRoot = this.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement;

                let thispcode = this.parentElement.parentElement.parentElement.querySelector('div.qty-m span.qty').getAttribute("id").replace("qty-",'');
                let thisPrice = parseFloat(this.parentElement.parentElement.parentElement.querySelector('span.product-price-mobile').innerText);

                Updatecart(thispcode, "pcode", 0, thisPrice);

                updateSummaryTotal();

                itemRoot.remove();
                DOMElement.cartElement.innerText = window.cartItems.length;
                DOMElement.cartMobileElement.innerText = `(${window.cartItems.length}) Cart`;
            });
        });

    }

    /////////////////////////////////////////////////////////////////
    // Checkout Page => Payment => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.paymentBtn) {
        DOMElement.paymentBtn.addEventListener('click', function(elem) {
            window.location.href = "/payment";
        });
    }

    /////////////////////////////////////////////////////////////////
    // Payment Page => Payment => Click Event
    /////////////////////////////////////////////////////////////////
    if (DOMElement.paymentProceed) {
        DOMElement.paymentProceed.addEventListener('click', function(elem) {
            window.location.href = "/thanks";
        });
    }

    ////////////////////////////////////////
    // Home Page => Add to Cart => Click Event
    ////////////////////////////////////////
    if (DOMElement.adToCartButton) {
        DOMElement.adToCartButton.forEach(function(elem) {
            elem.addEventListener("click", function() {
                let qtyElement = this.parentElement.parentElement.querySelector('a.qty span.qty');
                let qty = parseInt(qtyElement.innerText);
                if (qty > -1) {
                    let thispcode = this.parentElement.parentElement.querySelector('a.qty span.qty').getAttribute("id").replace("qty-",'');
                    let thisPrice = parseFloat(this.parentElement.parentElement.querySelector('span.product-price').innerText);

                    Updatecart(thispcode, "pcode", qty, thisPrice);

                    let btn = this.querySelector('span');
                    btn.innerText =  (qty > 0) ?  "Update Cart" : "Add to Cart";
                    DOMElement.cartElement.innerText = window.cartItems.length;
                    DOMElement.cartMobileElement.innerText = `(${window.cartItems.length}) Cart`;
                }
            });
        });
    }

    ////////////////////////////////////////
    // Home Page => Add Quantity => Click Event
    ////////////////////////////////////////
    if (DOMElement.itemPlus) {
        DOMElement.itemPlus.forEach(function(elem) {
            elem.addEventListener("click", function() {

                let qtyElement = this.parentElement.querySelector('span.qty');
                let qty = parseInt(qtyElement.innerText);
    
                if (qty < window.qtyMaxLimit) {
                    //Updatecart(this, 1);
                    qtyElement.innerText = qty + 1;

                    let itemPrice = qtyElement.parentElement.parentElement.parentElement.querySelector('span.item-price');
                    if (itemPrice) {
                        let itemMrp = parseInt(itemPrice.parentElement.parentElement.querySelector('span.product-price').innerText);

                        itemPrice.innerText = itemMrp * (qty + 1);
                    }
                }
                else {
                    console.log("ALERT: Quantity should not exceed to 100");
                }
            });
        });

        DOMElement.itemPlusMobile.forEach(function(elem) {
            elem.addEventListener("click", function() {

                let qtyElement = this.parentElement.querySelector('span.qty');
                let qty = parseInt(qtyElement.innerText);
    
                if (qty < window.qtyMaxLimit) {
                    //Updatecart(this, 1);
                    qtyElement.innerText = qty + 1;

                    let itemPrice = qtyElement.parentElement.parentElement.parentElement.querySelector('span.item-price-mobile');
                    if (itemPrice) {
                        let itemMrp = parseInt(itemPrice.parentElement.parentElement.querySelector('span.product-price-mobile').innerText);

                        itemPrice.innerText = itemMrp * (qty + 1);
                    }
                }
                else {
                    console.log("ALERT: Quantity should not exceed to 100");
                }
            });
        });
    }

    ////////////////////////////////////////
    // Home Page => Deduct Quantity => Click Event
    ////////////////////////////////////////
    if (DOMElement.itemMinus) {
        DOMElement.itemMinus.forEach(function(elem) {
            elem.addEventListener("click", function() {

                let qtyElement = this.parentElement.querySelector('span.qty');
                let qty = parseInt(qtyElement.innerText);
                if (qty > 0) {
                    //Updatecart(this, -1);
                    qtyElement.innerText = qty -1;

                    let itemPrice = qtyElement.parentElement.parentElement.parentElement.querySelector('span.item-price');
                    if (itemPrice) {
                        let itemMrp = parseInt(itemPrice.parentElement.parentElement.querySelector('span.product-price').innerText);

                        itemPrice.innerText = itemMrp * (qty - 1);
                    }
                }
                else {
                    console.log("ALERT: Quantity is 0");
                }
            });
        });

        DOMElement.itemMinusMobile.forEach(function(elem) {
            elem.addEventListener("click", function() {

                let qtyElement = this.parentElement.querySelector('span.qty');
                let qty = parseInt(qtyElement.innerText);
                if (qty > 0) {
                    //Updatecart(this, -1);
                    qtyElement.innerText = qty -1;

                    let itemPrice = qtyElement.parentElement.parentElement.parentElement.querySelector('span.item-price-mobile');
                    if (itemPrice) {
                        let itemMrp = parseInt(itemPrice.parentElement.parentElement.querySelector('span.product-price-mobile').innerText);

                        itemPrice.innerText = itemMrp * (qty - 1);
                    }
                }
                else {
                    console.log("ALERT: Quantity is 0");
                }
            });
        });
    }


    //////////////////////////////////////////////////
    // Home Page => Feature Product => Filter Events
    //////////////////////////////////////////////////
    if (DOMElement.featureProductFilterNonActive) {
        DOMElement.featureProductFilterNonActive.forEach(function(elem) {
            elem.addEventListener("click", function() {
                let activeElement = this.parentElement.querySelector('li.active');
                if (activeElement) {
                    activeElement.classList.remove('active');
                    activeElement.classList.add('nonactive');
                }
                this.classList.remove("nonactive");
                this.classList.add("active");
    
                let productNodeElement = this.parentElement.parentElement.parentElement.querySelectorAll('div.products li.item');
                if (productNodeElement) {
                    if (this.innerText.toUpperCase() == "ALL")
                    {
                        productNodeElement.forEach(function(elem) {
                            elem.classList.remove('fadeout');
                            elem.classList.add('fadein');
                        });
                    }
                    else {
                        productNodeElement.forEach(function(elem) {
                            elem.classList.remove('fadein');
                            elem.classList.add('fadeout');
                        });
    
                        let productFilterElement = this.parentElement.parentElement.parentElement.querySelectorAll(`div.products li.${this.innerText}`);
                        if (productFilterElement) {
                            productFilterElement.forEach(function(elem) {
                                elem.classList.remove('fadeout');
                                elem.classList.add('fadein');
                            });
                        }
                    }
                }
            });
        });


        ////////////////////////////////////////
        // Home Page => Feature Product => Accordion
        ////////////////////////////////////////
        DOMElement.featureCategories.forEach(function(elem) {
            elem.addEventListener("click", function() {
                //this function does stuff
                let productNodeElement = this.parentElement.parentElement.querySelector("div.products");
                if (this.classList.contains("close")) {
                    this.classList.add("open");
                    this.classList.remove("close");
        
                    productNodeElement.classList.add("fadeout");
                    productNodeElement.classList.remove("fadein");
                }
                else {
                    this.classList.remove("open");
                    this.classList.add("close");
        
                    productNodeElement.classList.add("fadein");
                    productNodeElement.classList.remove("fadeout");
                }
            });
        });
    
    }
});

const updateSummaryTotal = () => {
    if (DOMElement.subtotal) {
        let cartPricetotal = 0;
        window.cartItems.forEach(function(item) {
            cartPricetotal += (item.price * item.qty);
        });

        DOMElement.subtotal.innerText = cartPricetotal;
        DOMElement.grandSummary.innerText = cartPricetotal;
    }
}
