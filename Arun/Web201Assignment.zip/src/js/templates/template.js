export const carouselTemplate = (bullet, items) => {
    return `
    <div class="carousel-prev"></div>
    <div class="carousel-next"></div>
    <ul class="carousel-pagination">${bullet}</ul>
    <ul class="carousel-container">${items}</ul>
    `;
};

export const headerTemplate = () => {
    return `
    <div class="row row-first">
        <div class="logo">
            <img src="img/logo1.png" alt="Khana Khazana" title="Khana Khazana" class="logo" aria-label="Logo">
        </div>
        <div class="contact">
            <svg class="contact__icon">
                <use xlink:href="img/sprite.svg#icon-home"></use>
            </svg>

            <span>Okhla Main Road,<br/>Tughlakabad Extension,<br/>New Delhi, Delhi 110044</span>
        </div>
    </div>

    <div class="row row-content">
        <div class="mobile-menu">
            <svg class="mobile-menu__icon">
                <use xlink:href="img/sprite.svg#icon-menu"></use>
            </svg>
        </div>
        <div class="content">
            <nav class="nav-box">
                <div class="nav-box__item">
                    <a href="/">
                        <svg class="nav-box__item__icon">
                            <use xlink:href="img/sprite.svg#icon-home"></use>
                        </svg>
                        <span class="nav-box__label">Home</span>
                    </a>
                </div>
                <div class="nav-box__item">
                    <a href="/">
                        <svg class="nav-box__item__icon">
                            <use xlink:href="img/sprite.svg#icon-book"></use>
                        </svg>
                        <span class="nav-box__label">Category</span>
                    </a>
                </div>
                <div class="nav-box__item">
                    <a href="/">
                        <svg class="nav-box__item__icon">
                            <use xlink:href="img/sprite.svg#icon-user"></use>
                        </svg>
                        <span class="nav-box__label">Cart</span>
                    </a>
                </div>
                <div class="nav-box__item">
                    <a href="/">
                        <svg class="nav-box__item__icon">
                            <use xlink:href="img/sprite.svg#icon-user"></use>
                        </svg>
                        <span class="nav-box__label">Login</span>
                    </a>
                </div>
            </nav>

            <form action="#" class="search">
                <input type="text" class="search__input" placeholder="Search Your Food">
                <button class="search__button">
                    <svg class="search__icon">
                        <use xlink:href="img/sprite.svg#icon-search"></use>
                    </svg>
                </button>
            </form>
        </div>
    </div>`;
}

export const mobileHeaderTemplate = () => {
    return `
    <nav class="side-nav side-nav__active1">
        <div class="side-nav__main">
            <a href="#">
                <div aria-label="Arun Kumar" class="side-nav__user-avatar">
                    <span>AK</span>
                </div>
        
                <p class="side-nav__user">
                    <span class="side-nav__user__title">
                        Hello
                    </span>
                    <span class="side-nav__user__greet">
                        Welcome
                    </span>
                </p>
            </a>
        </div>
        <ul class="side-nav__link">
            <li class="side-nav__link__item">
                <a href="/">
                    <svg class="side-nav__link__item__icon">
                        <use xlink:href="img/sprite.svg#icon-home"></use>
                    </svg>
                    <span class="side-nav__link__item__label">Home</span>
                </a>
            </li>
            <li class="side-nav__link__item">
                <a href="/">
                    <svg class="side-nav__link__item__icon">
                        <use xlink:href="img/sprite.svg#icon-book"></use>
                    </svg>
                    <span class="side-nav__link__item__label">Category</span>
                </a>
            </li>
            <li class="side-nav__link__item">
                <a href="/">
                    <svg class="side-nav__link__item__icon">
                        <use xlink:href="img/sprite.svg#icon-book"></use>
                    </svg>
                    <span class="side-nav__link__item__label">Category</span>
                </a>
            </li>
            <li class="side-nav__link__item">
                <a href="/">
                    <svg class="side-nav__link__item__icon">
                        <use xlink:href="img/sprite.svg#icon-book"></use>
                    </svg>
                    <span class="side-nav__link__item__label">Category</span>
                </a>
            </li>
            <li class="side-nav__link__item">
                <a href="/">
                    <svg class="side-nav__link__item__icon">
                        <use xlink:href="img/sprite.svg#icon-book"></use>
                    </svg>
                    <span class="side-nav__link__item__label">Category</span>
                </a>
            </li>
            <li class="side-nav__link__item">
                <a href="/">
                    <svg class="side-nav__link__item__icon">
                        <use xlink:href="img/sprite.svg#icon-book"></use>
                    </svg>
                    <span class="side-nav__link__item__label">Cart</span>
                </a>
            </li>
        </ul>
    </nav>

    <div class="bg-overlay-popup"></div>`;
};

export const footerTemplate = () => {
    return `
    <footer>
        <div class="row">
            <div class="pages">
                <ul class="footer-nav">
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Product</a></li>
                </ul>
            </div>
            <div class="social">
                <ul class="social-icons">
                    <li>
                        <a href="/">
                            <svg class="item__icon">
                                <use xlink:href="img/sprite.svg#icon-facebook2"></use>
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="/">
                            <svg class="item__icon">
                                <use xlink:href="img/sprite.svg#icon-google-plus2"></use>
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="/">
                            <svg class="item__icon">
                                <use xlink:href="img/sprite.svg#icon-linkedin"></use>
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="/">
                            <svg class="item__icon">
                                <use xlink:href="img/sprite.svg#icon-tumblr2"></use>
                            </svg>
                        </a>
                    </li>
                    <li>
                        <a href="/">
                            <svg class="item__icon">
                                <use xlink:href="img/sprite.svg#icon-mail"></use>
                            </svg>
                        </a>
                    </li>
                    </ul>
            </div>
        </div>
        
        <div class="row">
            <p>Copyright © 2018 by Khana Khajana. All rights reserved</p>
        </div>
    </footer>`;
};
