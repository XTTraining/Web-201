// import * as firebase from 'firebase';
import {appFirebase} from '../init';
import {DOMElement} from '../../views/domelement';

//https://codepen.io/alemesa/pen/apKaPL?editors=1111

export const login = (mode) => {
    if (mode==="gmail") {
        gmailLogin();
    }
    if (window.localStorage.auth) {
        //appInit();
    }
};

const SendMessage = () => {
    // Initialize Firebase
    // var config = {
    //     apiKey: "AIzaSyAWWbAhVQsnsDNA_TbDa3ZOYjPF5KpMtdE",
    //     authDomain: "assignmentweb201.firebaseapp.com",
    //     databaseURL: "https://assignmentweb201.firebaseio.com",
    //     projectId: "assignmentweb201",
    //     storageBucket: "assignmentweb201.appspot.com",
    //     messagingSenderId: "652339367266"
    // };
    // appFirebase.initializeApp(config);

    const firebaseMessaging = appFirebase.messaging();
    firebaseMessaging.requestPermission().then(function() {
        console.log("Message Permission Granted!!!");
        return firebaseMessaging.getToken();
    })
    .then(function(token) {
        console.log("Token: ", token);
    })
    .catch(function(error) {
        console.log("Message Permission Denied", error);
    });

    firebaseMessaging.onMessage(function(payload) {
        console.log("Payload: ", payload);
    });
}

const appInit = () => {
    console.log("appInit");

    let carouselRef = appFirebase.database().ref("Carousel").orderByChild("title");

    carouselRef.once('value', function(snapshot) {
        let carouselData = '';
        snapshot.forEach(function(childSnapShot) {
            carouselData += 
            `<strong>${childSnapShot.val().title}</strong></br>
            <p>${childSnapShot.val().description}</p></br>
            <img src="${childSnapShot.val().image}" alt="${childSnapShot.val().title}" title="${childSnapShot.val().title}" />
            `;
        });
        console.log(carouselData);
        if (DOMElement.carousel) {
            DOMElement.carousel.insertAdjacentHTML('beforeend', carouselData);
        }
    });
};

const firebaseAppInitializer = () => {
};

const gmailLogin = () => {
    let provider = new appFirebase.auth.GoogleAuthProvider();

    if (DOMElement && DOMElement.gmail) {
        DOMElement.gmail.addEventListener("click", e=> {
            if (!window.localStorage.auth) {
                appFirebase.auth().signInWithPopup(provider).then(function(result) {
                    console.log("User is login: ", result.user);
                    window.localStorage.auth = JSON.stringify(result.user);
                    return result.user;
                }).catch(function(error) {
                    let errorCode = error.code;
                    let errorMessage = error.message;
                    console.log("Error: " + errorCode + ", Description: " + errorMessage);
                });
            }
            else {
                //console.log("Already Login: ", window.localStorage.auth);
                appInit();
            }
        });
        console.log("Gmail");
    }
    else {
        console.log("No Gmail");
    }
};
