export const DOMElement = {
    logo: document.querySelector('div.logo img'),
    header: document.querySelector('.header'),
    footer: document.querySelector('.footer'),
    gmail: document.querySelector("#gmail-login"),
    twitter: document.querySelector("#twitter-login"),
    facebook: document.querySelector("#facebook-login"),
    cartElement: document.querySelector("span.nav-box__label.cart"),
    cartMobileElement: document.querySelector("span.side-nav__link__item__label.mobile-side-cart"),
    carousel: document.querySelector("#carousel"),
    mobilemenu: document.querySelector(".mobile-menu"),
    sidenav: document.querySelector(".side-nav"),
    bgOverlayPopup: document.querySelector(".bg-overlay-popup"),
    featureCategories: document.querySelectorAll(".navbar .category"),
    featureProductFilterNonActive: document.querySelectorAll("ul.navbar-nav li.filter"),

    itemPlus: document.querySelectorAll("a.qty .icon-plus"),
    itemMinus: document.querySelectorAll("a.qty .icon-minus"),

    itemPlusMobile: document.querySelectorAll("div.qty-m .icon-plus"),
    itemMinusMobile: document.querySelectorAll("div.qty-m .icon-minus"),

    itemQty: document.querySelectorAll("span.qty"),
    adToCartButton: document.querySelectorAll("div.content div.action button"),
    updateCartButton: document.querySelectorAll("div.product-tr div.action a.update-cart"),
    removeCartButton: document.querySelectorAll("div.product-tr div.action a.delete-cart"),

    updateMobileCartButton: document.querySelectorAll("div.product-tr div.action a.update-cart-mobile"),
    removeMobileCartButton: document.querySelectorAll("div.product-tr div.action a.delete-cart-mobile"),

    subtotal: document.querySelector(".totals span.subtotal"),
    discountSummary: document.querySelector(".totals span.discount-summary"),
    couponSummary: document.querySelector(".totals span.coupon-summary"),
    grandSummary: document.querySelector(".totals span.grand-summary"),
    continueShop : document.querySelector('button.button.cont-shop'),
    clearCart : document.querySelector('button.button.clear-cart'),
    productsElement: document.querySelectorAll('.product-tr.product-row'),
    cartCheckoutbtn: document.querySelector('.inner .checkout button.button'),
    paymentBtn: document.querySelector('.inner .checkout button.payment-btn'),
    paymentProceed: document.querySelector('button.button.proceed')
};

export const ElementClasses = {
    sideNavActive: "side-nav__active",
    bgOverlayPopup: "bg-overlay-popup__active",
    featureproduct: '.products'
};


////// CAROUSEL Elements
