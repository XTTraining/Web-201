import $ from "jquery";

export const elements={
    restaurants:$('.results-placeholder'),
    filter:$('.content-placeholder')
    };