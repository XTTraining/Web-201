import data from './models/data';
import firebase from 'firebase';
import '../sass/main.scss';
import filter from '../hbs/filter.hbs';
import restaurant from '../hbs/restaurant.hbs';
require.context("../img/", true, /\.(png|svg|jpg|gif)$/);
import $ from "jquery";
import { elements } from './base';
import './views/hero';

(() => {
    firebase.database().ref('filters/').once('value', function (snap) {
        var context = snap.val();
        elements.filter.append(filter(context));
    });

    firebase.database().ref('restaurants/').once('value', function (snap) {
        var context = snap.val();
        elements.restaurants.append(restaurant(context));
    });

    elements.filter.unbind().click(function (e) {
        var ids = $(":checked").map((x, y) => y.id);
        if (ids.length > 0) {
            firebase.database().ref('restaurants/').once('value', function (snap) {
                var context = snap.val().filter(x => {
                    var result = ids.filter((e, ex) => {
                        return x.filtercodes.includes(ex);
                    });
                    return result.length > 0;
                });
                elements.restaurants.append(restaurant(context));
            });
        }
    });
})()


