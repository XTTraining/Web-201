import firebase from 'firebase';
import 'firebase/database/dist/index.cjs';
import * as constant from './config';


var config = {
    apiKey: constant.apiKey,
    authDomain: constant.authDomain,
    databaseURL: constant.databaseURL,
    projectId: constant.projectId,
    storageBucket: constant.storageBucket,
    messagingSenderId: constant.messagingSenderId
};
firebase.initializeApp(config);

