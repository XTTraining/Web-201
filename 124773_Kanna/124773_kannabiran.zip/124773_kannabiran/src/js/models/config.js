export const apiKey = "AIzaSyB_NUJxnsjt7NcuMsdXikmRJlMF0EHdzuo";
export const authDomain = "fooddelivery-485f2.firebaseapp.com";
export const databaseURL = "https://fooddelivery-485f2.firebaseio.com";
export const projectId = "fooddelivery-485f2";
export const storageBucket = "";
export const messagingSenderId = "817935122678";