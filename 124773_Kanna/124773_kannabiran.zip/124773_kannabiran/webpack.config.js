const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const autoprefixer = require('autoprefixer');
const webpack = require('webpack');

module.exports = {
    entry: ['babel-polyfill', './src/js/index.js'],
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'js/bundle.js'
    },
    devServer: {
        contentBase: './dist'
    },
    plugins: [
        new HtmlWebpackPlugin({
            filename: 'index.html',
            template: './src/index.html'
        }),
        new HtmlWebpackPlugin({
            filename: 'order.html',
            template: './src/order.html'
        }),
        new HtmlWebpackPlugin({
            filename: 'checkout.html',
            template: './src/checkout.html'
        }),
        new ExtractTextPlugin('css/style.css'),
        new webpack.LoaderOptionsPlugin({
            minimize: true,
            options: {
                postcss: [autoprefixer]
            }
        })
    ],
    module: {
        rules: [
            {
                test: /\.scss$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: ['css-loader', "postcss-loader", 'sass-loader']
                })
            },
            {
                test:  /\.(png|jpe?g|gif|svg|woff|woff2|ttf|eot|ico)(\?v=.+)?$/,
                loader:  'file-loader?name=img/[name].[ext]'
            },
            {
                test: /\.hbs$/,
                use: [{
                    loader: "handlebars-loader",
                    options: { helperDirs: path.resolve(__dirname, "./js/helpers") }
                }]
            }
        ]
    }
};