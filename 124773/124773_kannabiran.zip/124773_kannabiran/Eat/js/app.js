(() => {
    firebase.database().ref('filters/').once('value', function (snap) {
        var context = snap.val();
        var theTemplateScript = $("#filter-template").html();
        var theTemplate = Handlebars.compile(theTemplateScript);
        var theCompiledHtml = theTemplate(context);
        $('.content-placeholder').html(theCompiledHtml);
    });

    firebase.database().ref('restaurants/').once('value', function (snap) {
        var context = snap.val();
        var theTemplateScript = $("#results-template").html();
        var theTemplate = Handlebars.compile(theTemplateScript);
        var theCompiledHtml = theTemplate(context);
        $('.results-placeholder').html(theCompiledHtml);
    });

    $(".content-placeholder").unbind().click(function (e) {
        var ids = $(":checked").map((x, y) => y.id);
        if (ids.length > 0) {
            firebase.database().ref('restaurants/').once('value', function (snap) {
                var context = snap.val().filter(x => {
                    var result = ids.filter((e, ex) => {
                        return x.filtercodes.includes(ex);
                    });
                    return result.length > 0;
                });
                var theTemplateScript = $("#results-template").html();
                var theTemplate = Handlebars.compile(theTemplateScript);
                var theCompiledHtml = theTemplate(context);
                $('.results-placeholder').html(theCompiledHtml);
            });
        }
    });

})()

$("#slideshow > div:gt(0)").hide();

setInterval(function () {
    $('#slideshow > div:first')
        .fadeOut(1000)
        .next()
        .fadeIn(1000)
        .end()
        .appendTo('#slideshow');
}, 3000);