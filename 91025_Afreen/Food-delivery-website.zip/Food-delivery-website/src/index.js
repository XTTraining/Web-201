//alert("Hello world!!!");

import './js/firebase_app_script';
import './js/custom_jquery_code';
// import './js/gmap';

// import '../sass/main.scss';