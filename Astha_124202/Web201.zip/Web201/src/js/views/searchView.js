import { elements } from './base';
export const getInput = () => elements.searchInput.value;
export const setInput = () => elements.searchInput.value="";