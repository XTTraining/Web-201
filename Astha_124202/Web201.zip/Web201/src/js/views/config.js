export const apiKey= "AIzaSyBBph4l-Px25DyhYxmiOpaPX1OfW1DGLos";
export const authDomain= "dine-to-door.firebaseapp.com";
export const databaseURL= "https://dine-to-door.firebaseio.com";
export const projectId= "dine-to-door";
export const storageBucket= "dine-to-door.appspot.com";
export const messagingSenderId= "883878664097";