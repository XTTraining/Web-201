require.context("../img/", true, /\.(png|svg|jpg|gif)$/);
import style from "../_scss/main.scss"
import Navigation from "./models/Navigation";
import Product from "./models/Product";
import Category from "./models/Category";
import Carousel from "./models/Carousel";
import ShoppingBag from './models/ShoppingBag';
import './models/Menu';

import * as navigationView from './views/navigationView';
import * as categoryView from './views/categoryView';
import * as shoppingBagView from './views/shoppingBagView';
import * as paymentView from './views/paymentView';

import { elements, renderLoader, clearLoader } from './views/base';
import $ from 'jquery'

//Below state is responsible for populating firebase database. Hence please ignore
import { firebaseUpload } from './functions/utils/firebase.upload'

const state = {};

/***********Carousel Controller ************/

$(document).on('click', '.next, .prev', function (event) {
    try {
        if ($(this).hasClass('next')) {
            state.carousel.plusSlides(1);
        }
        else {
            state.carousel.plusSlides(-1);
        }
    } catch (error) {
        console.log(error);
    }
})

/***********Overlay Controller***********/

window.onclick = function (event) {
    try {
        if (event.target.id === "overlay-container") {
            $('.overlay-container').hide()
        }
    } catch (error) {
        console.log(error);
    }
};

$(document).on('click', '.continue-shopping-link, .modal-close__btn', function (event) {
    try {
        event.preventDefault();
        $('.overlay-container').hide();
    } catch (error) {
        console.log(error);
    }
});

$(document).on('click', '.cart-check-out .btn', function (event) {
    event.preventDefault();
    window.location.href = '/checkout.html?page=checkout'
})

/***********Filter Controller****************/

$(document).on('click', '.filter-container a', function (event) {
    try {
        event.preventDefault();
        const id = $(this).data('key');
        const context = state.category.Categories;
        if (id) {
            const categories = context.filter(category => category.key === id);
            if (!categoryView) state.categoryView = new categoryView();
            categoryView.render(categories, id);
        }
        else {
            categoryView.render(context);
        }
    } catch (error) {
        console.log(error);
    }
});

/* =============Shopping Bag controller ===============*/


//Cart Button Click
$(document).on('click', '.js-add-to-cart', function () {
    try {
        //prepareUI

        const id = $(this).data('key');

        //Initialize shopping bag instance
        if (!state.shoppingBag) state.shoppingBag = new ShoppingBag(state.category.Categories);

        //Add the product to Shopping Bag and increase the count
        const product = state.product.Products.find(product => product.key === id);
        state.shoppingBag.add(product);

        state.shoppingBag.displayCount($(this).prev().find('.add-to-cart__quantity'), product)
        //Display the count in the notificatin
        state.shoppingBag.displayCountNotification();


        state.shoppingBag.prepareUI(this);

        //prepareUI

    } catch (error) {
        console.log(error);
    }
});


// Plus button clicked on the main page
$(document).on('click', '.panel .add-to-cart__inc', function (event) {
    try {
        //get product id
        const id = $(this).data('key');

        //Initialize shopping bag instance
        if (!state.shoppingBag) state.shoppingBag = new ShoppingBag(state.category.Categories);
        const product = state.product.Products.find(product => product.key === id);

        //Add the product to Shopping Bag and increase the count
        state.shoppingBag.add(product);
        state.shoppingBag.displayCount($(this).prev(), product)

        //Display the count on the cart icon
        state.shoppingBag.displayCountNotification();
    } catch (error) {
        console.log(error);
    }

});

// Plus button clicked on the main page
$(document).on('click', '.panel .add-to-cart__dec', function (event) {
    try {
        //get product id
        const id = $(this).data('key');

        //Remove the product from Shopping Bag and decrease the count
        if (!state.shoppingBag) state.shoppingBag = new ShoppingBag(state.category.Categories);
        const product = state.product.Products.find(product => product.key === id);
        const count = state.shoppingBag.remove(product);
        state.shoppingBag.displayCount($(this).next(), product)
        if (count === 0) {
            state.shoppingBag.resetUI(this);
        }

        //Display the count on the cart icon
        state.shoppingBag.displayCountNotification();
    } catch (error) {
        console.log(error);
    }
});

/**********Cart Controller************** */

//Header Cart icon click 
$('.header__cart__button, .check-out-bottom a').on('click', function (event) {
    try {
        event.preventDefault();
        if (!state.shoppingBag) state.shoppingBag = new ShoppingBag(state.category.Categories);
        shoppingBagView.render(state.shoppingBag);
        $('.overlay-container').show();
    } catch (error) {
        console.log(error);
    }
})

/**********Accordion Controller **************/

const prepareUIforCategoryButtonClick = (el) => {
    try {
        $(el).toggleClass('accordion_active');
        var panel = $(el).next();
        if ($(panel).is(':visible')) {
            $(panel).hide();
        }
        else {
            $(panel).show();
        }
    } catch (error) {
        console.log(error)
    }
}

//Accodion button click
$(document).on('click', elements.btnCategories, (event) => {

    try {
        const _this = event.target;
        prepareUIforCategoryButtonClick(_this);
        const categoryKey = $(_this).attr('data-category-id');
        const category = state.category.Categories.find(category => category.key === categoryKey);
        const products = state.product.Products.filter(product => product.key in category.value.products);
        if (!state.shoppingBag) state.shoppingBag = new ShoppingBag(state.category.Categories);
        categoryView.renderProducts(products, categoryKey, state.shoppingBag.products);
    }
    catch (error) {
        console.log(error);
    }

});

const initCheckOut = () => {
    try {
        paymentView.render(state.shoppingBag);
    } catch (error) {
        console.log(error);
    }
}

const init = async () => {

    try {

        //Prepare the UI - start the loading spinner

        renderLoader();

        if (!state.navigation) state.navigation = new Navigation();
        if (!state.category) state.category = new Category();
        if (!state.product) state.product = new Product();

        await state.navigation.getResults();
        await state.category.getResults();
        await state.product.getResults();

        if (!state.shoppingBag) state.shoppingBag = new ShoppingBag(state.category.Categories);

        const urlParams = new URLSearchParams(location.search);
        if (urlParams.has('page')) {
            initCheckOut();
            return;
        }

        categoryView.render(state.category.Categories);
        categoryView.renderFilter(state.category.Categories);
        navigationView.render(state.navigation.Navigations);

        //state.shoppingBag.clearCart();
        state.shoppingBag.displayCountNotification();

        if (!state.carousel) state.carousel = new Carousel();
        state.carousel.init();

        clearLoader();

    }
    catch (error) {
        console.log(error);
    }
}

window.addEventListener('load', init);

//Below function is responsible for populating firebase database. Hence please ignore.
//firebaseUpload();










