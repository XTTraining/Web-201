import hbsPayment from "../templates/payment.hbs";

export const render = (shoppingBag) => {

    if (shoppingBag.products.length > 0) {
        shoppingBag.subTotal = shoppingBag.products.map(prod => (prod.noOfItemsInCart * prod.value.amount)).reduce((a, b) => a + b, 0);
        shoppingBag.tax = Math.ceil(shoppingBag.products.map(prod => (prod.tax * prod.noOfItemsInCart * prod.value.amount) / 100).reduce((a, b) => a + b, 0));
        shoppingBag.totalPrice = Math.ceil([shoppingBag.subTotal, shoppingBag.tax].reduce((a, b) => a + b, 0));
        shoppingBag.count = shoppingBag.products.map(prod => (prod.noOfItemsInCart)).reduce((a, b) => a + b, 0);
    } else {
        shoppingBag.subTotal = 0;
        shoppingBag.tax = 0;
        shoppingBag.totalPrice = 0;
        shoppingBag.count = 0;
    }

    const html = hbsPayment(shoppingBag);
    document.getElementById('hbs-checkout').innerHTML = html;


}