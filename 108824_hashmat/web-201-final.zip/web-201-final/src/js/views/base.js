import $ from 'jquery';

export const elements = {
    btnCategories: '.accordion__btn',
    container: '.container'
};

export const elementStrings = {
    loader: 'loader-container'
};

export const renderLoader = () => {
    const loader = `
        <div class="${elementStrings.loader}">
            <div class="loader"></div>
        </div>
    `;
    $('.container').prepend(loader);
};

export const clearLoader = () => {
    $('.loader-container').remove();
}

