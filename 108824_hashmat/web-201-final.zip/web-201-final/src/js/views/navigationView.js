
import $ from 'jquery'
import hbsHeaderNav from "../templates/header.navigation.hbs";

export const render = (context) => {
    const navigationTemplateHTML = hbsHeaderNav({ navs: context });
    $('.js-nav').html(navigationTemplateHTML);
}