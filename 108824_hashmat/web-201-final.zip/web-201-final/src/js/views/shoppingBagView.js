import hbsShoppingBag from "../templates/shoppingBag.hbs";

export const render = (shoppingBag) => {

    // const { products, categories } = shoppingBag;
    // let prods = [];

    // const mainCategories = categories.filter(category => category.value.parent_id === 0);

    // if (products && products.length > 0) {
    //     const uniqueKeys = [...(new Set(products.map(({ key }) => key)))];
    //     if (uniqueKeys && uniqueKeys.length > 0) {
    //         shoppingBag.totalItems = uniqueKeys.length;
    //         uniqueKeys.forEach(id => {
    //             let prod = products.find(product => product.key === id);
    //             const category = mainCategories.find(({ key }) => Object.keys(prod.value.categories).includes(key));
    //             prod.noOfItemsInCart = products.filter(({ key }) => key === id).length
    //             prod.tax = category.value.tax;
    //             prod.total = prod.noOfItemsInCart * prod.value.amount;
    //             prods.push(prod);
    //         });
    //     }
    // }

    // shoppingBag.prods = prods;

    // const subTotal = shoppingBag.prods.map(prod => (prod.noOfItemsInCart * prod.value.amount)).reduce((a, b) => a + b, 0);
    // const tax = shoppingBag.prods.map(prod => (prod.tax * prod.noOfItemsInCart * prod.value.amount) / 100).reduce((a, b) => a + b, 0);

    // shoppingBag.subTotal = subTotal;
    // shoppingBag.tax = tax;
    // shoppingBag.total = [subTotal, tax].reduce((a, b) => a + b, 0);

    if (shoppingBag.products.length > 0) {
        shoppingBag.subTotal = shoppingBag.products.map(prod => (prod.noOfItemsInCart * prod.value.amount)).reduce((a, b) => a + b, 0);
        shoppingBag.tax = Math.ceil(shoppingBag.products.map(prod => (prod.tax * prod.noOfItemsInCart * prod.value.amount) / 100).reduce((a, b) => a + b, 0));
        shoppingBag.totalPrice = Math.ceil([shoppingBag.subTotal, shoppingBag.tax].reduce((a, b) => a + b, 0));
        shoppingBag.count = shoppingBag.products.map(prod => (prod.noOfItemsInCart)).reduce((a, b) => a + b, 0);
    }

    const html = hbsShoppingBag(shoppingBag);
    document.getElementById('overlay-container').innerHTML = html;
}