import hbsCategory from "../templates/categories.hbs";
import hbsProducts from "../templates/products.hbs";
import hbsfilter from "../templates/filter.hbs";

export const render = (context, id = 0) => {
    let categories;
    if (id === 0) {
        categories = context.filter(category => category.value.parent_id === id);
    }
    else {
        categories = context.filter(category => category.key === id);
    }
    const html = hbsCategory({ categories: categories });
    document.getElementById('hbs-categories').innerHTML = html;
}

export const renderFilter = (context) => {
    const categories = context.filter(category => category.value.parent_id === 0);
    categories.forEach(category => {
        const subCategories = context.filter(cat => cat.value.parent_id === category.key);
        category.subCategories = subCategories;
    });
    const html = hbsfilter({ categories: categories });
    document.getElementById('categories__container').innerHTML = html;
}

export const renderProducts = (context, id, cartItems) => {

    cartItems.forEach(cart => {
        let prod = context.find(product => product.key === cart.key);
        if (prod) {
            prod.isAddedToCart = true;
            prod.noOfItemsInCart = cart.noOfItemsInCart;
        }
    })


    const html = hbsProducts({ products: context });
    document.getElementById('panel-' + id).innerHTML = html;
}