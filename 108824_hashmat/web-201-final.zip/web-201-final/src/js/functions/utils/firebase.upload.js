import firebase from 'firebase';
import '../firebase.common'

export const firebaseUpload = () => {

    //Firebase data upload
    // var navigation = firebase.database().ref('navigation');
    // var navigation = firebase.database().ref("navigation/");

    // navigation.set({
    //     Home: {
    //         title: "Home",
    //         Link: "/home"
    //     },
    //     Shop: {
    //         title: "Shop",
    //         Link: "/shop"
    //     },
    //     Vegetable: {
    //         title: "Vegetable",
    //         Link: "/Vegetable"
    //     },
    //     Fruit: {
    //         title: "Fruit",
    //         Link: "/fruit"
    //     },
    //     Dried: {
    //         title: "Dried",
    //         Link: "/dried"
    //     },
    //     AboutUs: {
    //         title: "About Us",
    //         Link: "/aboutus"
    //     }
    // });

    var db = firebase.database();
    const categoriesData = [
        {
            category_name: "Shops",
            parent: false,
            tax: 12,
            sub_categories: [
                {
                    category_name: "Atta",
                    parent: true,
                    products: [
                        {
                            title: "Atta - Whole Wheat Atta",
                            amount: 340,
                            short_description: "",
                            src: 'img/products/atta_whole_wheat.jpg',
                            altText: 'Atta - Whole Wheat Atta'
                        },
                        {
                            title: "Atta - Multi Grains",
                            amount: 269,
                            short_description: "",
                            src: 'img/products/atta_multi_grain.jpg',
                            altText: 'Atta - Whole Wheat Atta'
                        },
                        {
                            title: "Atta Select",
                            amount: 237,
                            short_description: "",
                            src: 'img/products/atta-select.jpg',
                            altText: 'Atta Select'
                        }
                    ]
                },
                {
                    category_name: "Rice",
                    parent: true,
                    products: [
                        {
                            title: "Brown Rice",
                            amount: 579,
                            short_description: "",
                            src: 'img/products/organic-brown-rice.jpg',
                            altText: 'Brown Rice'
                        },
                        {
                            title: "Basmati Rice",
                            amount: 371,
                            short_description: "",
                            src: 'img/products/india-gate-basmati-rice.jpg',
                            altText: 'Basmati Rice'
                        },
                        {
                            title: "Jeeraga Samba",
                            amount: 469,
                            short_description: "",
                            src: 'img/products/rice-jeerajeeraga-samba.jpg',
                            altText: 'Jeeraga Samba'
                        }
                    ]
                }
            ]
        },
        {
            category_name: "Fruits",
            parent: false,
            tax: 12,
            sub_categories: [
                {
                    category_name: "Exotic Fruits",
                    parent: true,
                    products: [
                        {
                            title: "Grapes Bangalore Blue",
                            amount: 99,
                            short_description: "",
                            src: 'img/products/fresho-grapes-bangalore-blue.jpg',
                            altText: 'Grapes Bangalore Blue'
                        },
                        {
                            title: "Fresh Figs",
                            amount: 150,
                            short_description: "",
                            src: 'img/products/fresho-fresh-figs.jpg',
                            altText: 'Fresh Figs'
                        },
                        {
                            title: "Dragon Fruit",
                            amount: 49,
                            short_description: "",
                            src: 'img/products/fresho-dragon-fruit.jpg',
                            altText: 'Dragon Fruit'
                        }
                    ]
                },
                {
                    category_name: "Fresh Fruits",
                    parent: true,
                    products: [
                        {
                            title: "Banana - Yelakki",
                            amount: 72,
                            short_description: "",
                            src: 'img/products/fresho-banana-yelakki.jpg',
                            altText: 'Banana - Yelakki'
                        },
                        {
                            title: "Mango - Neelam",
                            amount: 55,
                            short_description: "",
                            src: 'img/products/fresho-mango-neelam.jpg',
                            altText: 'Mango - Neelam'
                        },
                        {
                            title: "Apple - Fuji, Regular",
                            amount: 180,
                            short_description: "",
                            src: 'img/products/fresho-apple-fuji-regular.jpg',
                            altText: 'Apple - Fuji, Regular'
                        }
                    ]
                }
            ]
        },
        {
            category_name: "Vegetables",
            parent: false,
            tax: 5,
            sub_categories: [
                {
                    category_name: "Fresh Vegetables",
                    parent: true,
                    products: [
                        {
                            title: "Ladies Finger",
                            amount: 40,
                            short_description: "",
                            src: 'img/products/fresho-ladies-finger-organically-grown.jpg',
                            altText: 'Ladies Finger'
                        },
                        {
                            title: "Palak",
                            amount: 20,
                            short_description: "",
                            src: 'img/products/fresho-palak-organically-grown.jpg',
                            altText: 'Palak'
                        },
                        {
                            title: "Carrot",
                            amount: 40,
                            short_description: "",
                            src: 'img/products/fresho-carrot-organically-grown.jpg',
                            altText: 'Carrot'
                        }
                    ]
                },
                {
                    category_name: "Exotic Veggies",
                    parent: true,
                    products: [
                        {
                            title: "Broccoli",
                            amount: 260,
                            short_description: "",
                            src: 'img/products/fresho-asparagus.jpg',
                            altText: 'Broccoli'
                        },
                        {
                            title: "Asparagus",
                            amount: 364,
                            short_description: "",
                            src: 'img/products/fresho-apple-fuji-regular.jpg',
                            altText: 'Asparagus'
                        },
                        {
                            title: "Chinese Cabbage",
                            amount: 69,
                            short_description: "",
                            src: 'img/products/fresho-chinese-cabbage.jpg',
                            altText: 'Chinese Cabbage'
                        }
                    ]
                }
            ]
        }
    ]

    var categoriesRef = db.ref('/categories');
    var productsRef = db.ref('/products');
    categoriesData.forEach(category => {
        var key = categoriesRef.push().key;
        var updates = {};
        updates['/categories/' + key + '/category_name'] = category.category_name;
        updates['/categories/' + key + '/parent_id'] = 0;
        updates['/categories/' + key + '/tax'] = category.tax;
        db.ref().update(updates);
        addSubCategory(key, category.sub_categories);
    });

    function addSubCategory(mainCategoryKey, subCategories) {
        subCategories.forEach(function (subCategory) {
            var subCategoryKey = categoriesRef.push().key;
            var updates = {};
            updates['/categories/' + subCategoryKey + '/category_name'] = subCategory.category_name;
            updates['/categories/' + subCategoryKey + '/parent_id'] = mainCategoryKey;
            db.ref().update(updates);

            addProducts(mainCategoryKey, subCategoryKey, subCategory.products);
        });
    }

    function addProducts(mainCategoryKey, subCategoryKey, products) {
        products.forEach(product => {
            var productKey = productsRef.push().key;
            var updates = {};
            updates['/categories/' + mainCategoryKey + '/products/' + productKey] = true;
            updates['/categories/' + subCategoryKey + '/products/' + productKey] = true;

            updates['/products/' + productKey + '/title'] = product.title;
            updates['/products/' + productKey + '/amount'] = product.amount;
            updates['/products/' + productKey + '/short_description'] = product.short_description;
            updates['/products/' + productKey + '/image_src'] = product.src;
            updates['/products/' + productKey + '/image_alt'] = product.altText;
            updates['/products/' + productKey + '/categories/' + mainCategoryKey] = true;
            updates['/products/' + productKey + '/categories/' + subCategoryKey] = true;

            db.ref().update(updates);
        });
    }


}