import firebase from 'firebase';
import '../functions/firebase.common'

export default class Navigation {

    async getResults() {
        const navigationRef = firebase.database().ref('navigation');
        await navigationRef.once('value').then(value => {
            if (value.exists() && value.hasChildren()) {
                this.Navigations = value.val();
            }
        });
    }
}   
