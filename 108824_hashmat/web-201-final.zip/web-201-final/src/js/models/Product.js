import firebase from 'firebase';
import '../functions/firebase.common'

export default class Product {
    constructor() {
        this.db = firebase.database();
    }

    async getResults() {
        const productsRef = this.db.ref('/products')
        await productsRef.once('value').then(value => {
            if (value.exists() && value.hasChildren()) {
                var data = [];
                value.forEach(_child => {
                    data.push({
                        key: _child.key,
                        value: _child.val()
                    })
                });
                this.Products = data;
            }
        })
    }
}   
