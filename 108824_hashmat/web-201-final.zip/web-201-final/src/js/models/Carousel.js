var slideIndex = 1;

export default class Carousel {

    constructor() {

    }

    init() {
        this.slideIndex = 1
        this.showSlides(slideIndex);
    }

    getSlideIndex() {
        return this.slideIndex;
    }

    plusSlides(n) {
        this.showSlides(this.slideIndex += n);
    }

    currentSlide(n) {
        this.showSlides(this.slideIndex = n);
    }

    showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("slides");
        if (n > slides.length) { this.slideIndex = 1 }
        if (n < 1) { this.slideIndex = slides.length }
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slides[this.slideIndex - 1].style.display = "block";
    }

}