import firebase from 'firebase';
import '../functions/firebase.common'

export default class Category {
    constructor() {
        this.db = firebase.database();
    }

    async getResults() {
        const categories = this.db.ref('/categories');
        await categories.once('value').then(value => {
            if (value.exists() && value.hasChildren()) {
                var data = [];
                value.forEach(_child => {
                    data.push({
                        key: _child.key,
                        value: _child.val()
                    })
                });
                this.Categories = data;
            }
        });
    }
}

