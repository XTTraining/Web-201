import $ from 'jquery';

export default class ShoppingBag {

    constructor(categories) {
        this.readStorage();
        this.categories = categories;
    }

    init(categories) {
        this.categories = categories;
    }

    displayCount(element, product) {
        if (this.products.length > 0) {
            let prod = this.products.find(prod => prod.key === product.key);
            if (prod) {
                $(element).text(prod.noOfItemsInCart);
            }
        }
    }

    add(product) {
        if (product) {
            const category = this.categories.find(({ key }) => Object.keys(product.value.categories).includes(key));
            const tax = category.value.tax;
            let noOfItemsInCart = 1;

            if (this.products.length > 0) {
                let prod = this.products.find(prod => prod.key === product.key);
                if (prod) {
                    prod.noOfItemsInCart++;
                    prod.total = prod.noOfItemsInCart * prod.value.amount;
                    this.updateShoppingBag();
                    return;
                }
            }
            product.tax = tax;
            product.noOfItemsInCart = noOfItemsInCart;
            product.total = product.noOfItemsInCart * product.value.amount;
            this.products.push(product);
            this.updateShoppingBag();
        }
    }

    updateShoppingBag() {
        if (this.products.length > 0) {
            this.subTotal = this.products.map(prod => (prod.noOfItemsInCart * prod.value.amount)).reduce((a, b) => a + b, 0);
            this.tax = Math.ceil(this.products.map(prod => (prod.tax * prod.noOfItemsInCart * prod.value.amount) / 100).reduce((a, b) => a + b, 0));
            this.totalPrice = Math.ceil([this.subTotal, this.tax].reduce((a, b) => a + b, 0));
            this.count = this.products.map(prod => (prod.noOfItemsInCart)).reduce((a, b) => a + b, 0);
        } else {
            this.subTotal = 0;
            this.tax = 0;
            this.totalPrice = 0;
            this.count = 0;
        }
        this.persistData();
    }

    remove(product) {
        if (this.products.length > 0) {
            let noOfItemsInCart;
            let prod = this.products.find(prod => prod.key === product.key);
            if (prod) {
                prod.noOfItemsInCart--;
                if (prod.noOfItemsInCart === 0) {
                    const index = this.products.findIndex(product => product.key === product.key);
                    if (index !== -1) {
                        this.products.splice(index, 1);
                    }
                }
                this.updateShoppingBag();
                return prod.noOfItemsInCart;
            } else {
                throw new Error('Product not present in the cart');
            }


        }
    }

    displayCountNotification() {
        let count = 0
        if (this.products.length > 0) {
            count = this.products.map(prod => (prod.noOfItemsInCart)).reduce((a, b) => a + b, 0);
        }
        $('.header__cart__notification').text(count);
    }

    prepareUI(element) {
        $(element).hide();
        $(element).prev().show();
    }

    resetUI(element) {
        $(element).closest('.add-to-cart-icons').hide();
        $(element).closest('.add-to-cart-icons').next().show();
    }

    clearCart() {
        this.products = [];
        this.persistData();
    }

    persistData() {
        localStorage.setItem('cart', JSON.stringify(this.products));
    }

    readStorage() {
        const cart = JSON.parse(localStorage.getItem('cart'));
        if (cart) {
            this.products = cart;
        } else {
            this.products = [];
        }
    }
}