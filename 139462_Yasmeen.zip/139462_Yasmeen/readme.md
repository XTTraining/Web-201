Just Eat - Food  Delivery App

Getting Started

Prerequisites:

1. npm
2. Node.js

Install  node.js.

https://nodejs.org/en/download/



Installing:

To set up the application in our local end, we have to follow the steps given below:

1) First fetch the application from the git repository (https://github.com/XTTraining/Web-101.git).

2) Once code downloaded gets completed, then install all the node modules.

In command Prompt go to the project source folder and give commands:

Step1 : npm install
step2 : npm run dev/ build
Step3 : npm run start



Authors:
Yasmeen Hasan
 