  // Initialize Firebase
  import firebase from 'firebase';

  // Initialize Firebase
  export const config = {
    apiKey: "AIzaSyCxXvnY7FqsaKdRZS5AUb-jBdlIWpvbdfc",
    authDomain: "justeat-59af3.firebaseapp.com",
    databaseURL: "https://justeat-59af3.firebaseio.com",
    projectId: "justeat-59af3",
    storageBucket: "justeat-59af3.appspot.com",
    messagingSenderId: "733194223482"
  };
  firebase.initializeApp(config);