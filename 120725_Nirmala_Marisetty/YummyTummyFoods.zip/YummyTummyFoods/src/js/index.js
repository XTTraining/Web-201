// Get the data from firbase
import firebase from "firebase";
import "../sass/main.scss";
require.context("../img/", true, /\.(png|svg|jpg|gif)$/);

import { elements, renderLoader, clearLoader, elementStrings } from "./views/base";
import "./categoryfiltering";
import "./firebase.config";
import * as categoryitemview from "./views/categoryitemview";
import $ from "jquery";
import "./header";
import "./carousel";

const getItems = async () => {
  const databaseRef = firebase.database().ref("fooditems/");

  let count = 0;
  await databaseRef.on("value", function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
      let data = childSnapshot.val();
      let key = childSnapshot.key;
      
     let heading =
        `<div id="${key.toLowerCase()}">
            <div class="categoriesname">${key}</div>
        </div>`;
     
      $(".categorieitems").append(heading);
      let items = `<div class="rightside" id="items_${count}"></div>`;
      let itemsid = "items_" + count;
      $("#" + key.toLowerCase()).append(items);
      count = count + 1;
      data.forEach(function(product) {
        categoryitemview.render(itemsid, product);
      });
    });
  });
};

const init = async () => {
  await getItems();
};

$(document).on("click", ".quantity__plus", function() {
    const id = $(this).data("id");
    let title = $(this).closest(".list").find("h3").text();
    let quantity = $(this).prev().text();
    let amount = $(this).closest(".list").find("span").text();

    Items.addToCart(id, title, amount, quantity);
});

window.addEventListener("load", init);

// Add to cart functionality

export default class Items {
  constructor() {
    this.items = [];
  }

  addToCart(id, title, amount, quantity) {
    const item = { id, title, amount, quantity };
    this.items.push(item);

    // Perist data in localStorage
    this.persistData();

    return item;
  }

  persistData() {
    localStorage.setItem("items", JSON.stringify(this.items));
  }

  readStorage() {
    const storage = JSON.parse(localStorage.getItem("items"));

    // Restoring items from the localStorage
    if (storage) this.items = storage;
  }
}
