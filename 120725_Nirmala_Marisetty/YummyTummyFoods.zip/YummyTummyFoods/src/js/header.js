window.onscroll = function () {
    navigation()
};
let navbar = $("#navbar");
let sticky = navbar.offset().top;

function navigation() {
    if (window.pageYOffset >= sticky) {
        navbar.addClass("sticky")
    } else {
        navbar.removeClass("sticky");
    }
}

$(".main").find("a").click(function(e) {
    e.preventDefault();
    let section = $(this).attr("href");
    $("html, body").animate({
        scrollTop: $(section).offset().top - 180
    });
});