import categoryItemTemplate from '../hbsTemplates/categoryItemTemplate.hbs';
import $ from 'jquery';

export const render = (parentId, product) => {
  const html = categoryItemTemplate(product);
  $('#' + parentId).append(html);
}

