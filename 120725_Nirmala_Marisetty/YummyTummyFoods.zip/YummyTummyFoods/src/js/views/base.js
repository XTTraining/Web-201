export const elements = {

    incButton:  document.querySelector('.quantity__plus'),
    item: document.querySelector('.item'),
    
};
