        
import firebase from "firebase";
import 'firebase/database';

  // Initialize Firebase
  
  let config = {
    apiKey: "AIzaSyBdEoqAd9u-61FH0yGQaNP7ma606CZEHBo",
    authDomain: "yummy-food-9bb1b.firebaseapp.com",
    databaseURL: "https://yummy-food-9bb1b.firebaseio.com",
    projectId: "yummy-food-9bb1b",
    storageBucket: "yummy-food-9bb1b.appspot.com",
    messagingSenderId: "359147316264"
  };
  firebase.initializeApp(config);